"""
MPLADS SENTINEL API  (owner: Member 3)

    uvicorn api.main:app --reload --port 8000
    open http://localhost:8000/docs

Design notes for Q&A:
 - The pipeline runs ONCE at startup and holds results in memory. On 2,500
   projects the whole run is under a second, so there is no cache-invalidation
   problem and no UI latency during a demo. At national scale (approx. 1.5-2
   lakh works a year) the same code runs as a nightly batch into PostgreSQL +
   PostGIS, and the API reads materialised tables; the engine code does not
   change, only where the results are stored.
 - Read endpoints are stateless. The only write endpoint is the disposal
   action, which appends to the hash-chained ledger - it never mutates history.
 - Role-based views (MINISTRY / DM / MP) are the same data at different
   aggregation levels, so there is exactly one source of truth.
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fastapi import FastAPI, HTTPException, Query           # noqa: E402
from fastapi.middleware.cors import CORSMiddleware          # noqa: E402
from fastapi.responses import FileResponse                  # noqa: E402
from pydantic import BaseModel                              # noqa: E402

from sentinel import dossier as dossier_mod                 # noqa: E402
from sentinel.engines import structuring                    # noqa: E402
from sentinel.pipeline import run_all                       # noqa: E402
from sentinel.risk import AuditLedger, aggregate, score_all # noqa: E402
from sentinel.schema import load_projects                   # noqa: E402

app = FastAPI(title="MPLADS Sentinel API", version="1.0",
              description="Forensic risk intelligence layer for MPLADS works.")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"],
                   allow_headers=["*"])

STATE: dict = {}


@app.on_event("startup")
def boot():
    projects = load_projects(ROOT / "data" / "projects.csv")
    findings, timings = run_all(projects, verbose=False)
    packets = aggregate(projects, findings)
    STATE.update({
        "projects": projects,
        "index": {p["project_id"]: p for p in projects},
        "findings": findings,
        "packets": packets,
        "rows": score_all(projects, packets),
        "timings": timings,
        "concentration": structuring.concentration_report(projects),
        "ledger": AuditLedger(ROOT / "out" / "ledger.jsonl"),
    })


@app.get("/api/v1/health")
def health():
    return {"status": "ok", "projects": len(STATE["projects"]),
            "engine_timings_ms": STATE["timings"]}


@app.get("/api/v1/projects")
def projects(district: str | None = None, risk_band: str | None = None,
             status: str | None = None, category: str | None = None,
             min_score: int = 0, limit: int = Query(200, le=5000), offset: int = 0):
    rows = STATE["rows"]
    if district:
        rows = [r for r in rows if r["district"] == district]
    if risk_band:
        rows = [r for r in rows if r["risk_band"] == risk_band.upper()]
    if status:
        rows = [r for r in rows if r["status"] == status.upper()]
    if category:
        rows = [r for r in rows if r["work_category"] == category.upper()]
    rows = [r for r in rows if r["overall_risk_score"] >= min_score]
    rows = sorted(rows, key=lambda r: -r["overall_risk_score"])
    return {"total": len(rows), "items": rows[offset:offset + limit]}


@app.get("/api/v1/projects/{project_id}")
def project_detail(project_id: str):
    if project_id in STATE["packets"]:
        return STATE["packets"][project_id]
    p = STATE["index"].get(project_id)
    if not p:
        raise HTTPException(404, "Project not found")
    return {"project_id": project_id, "overall_risk_score": 0, "risk_band": "LOW",
            "anomalies": [], **p}


@app.get("/api/v1/analytics/kpi")
def kpi(district: str | None = None):
    rows = STATE["rows"]
    if district:
        rows = [r for r in rows if r["district"] == district]
    sanctioned = sum(r["sanctioned_amount"] for r in rows)
    released = sum(r["released_amount"] for r in rows)
    high = [r for r in rows if r["risk_band"] == "HIGH"]
    return {
        "total_works": len(rows),
        "total_sanctioned_inr": sanctioned,
        "total_released_inr": released,
        "utilisation_pct": round(100 * released / sanctioned, 2) if sanctioned else 0,
        "high_risk_works": len(high),
        "medium_risk_works": sum(1 for r in rows if r["risk_band"] == "MEDIUM"),
        "exposure_flagged_inr": sum(r["amount_at_risk"] for r in rows),
        "exposure_high_risk_inr": sum(r["amount_at_risk"] for r in high),
        "completed_pct": round(100 * sum(1 for r in rows if r["status"] == "COMPLETED")
                               / len(rows), 1) if rows else 0,
    }


@app.get("/api/v1/analytics/concentration")
def concentration(band: str | None = None, limit: int = 25):
    data = STATE["concentration"]
    if band:
        data = [c for c in data if c["concentration_band"] == band.upper()]
    return {"total": len(data), "items": data[:limit]}


@app.get("/api/v1/analytics/timeline")
def timeline():
    """Monthly sanction value - drives the March-spike chart."""
    from collections import defaultdict
    buckets = defaultdict(lambda: {"value": 0, "works": 0, "flagged": 0})
    for r in STATE["rows"]:
        m = r["sanction_date"][:7]
        buckets[m]["value"] += r["sanctioned_amount"]
        buckets[m]["works"] += 1
        if r["risk_band"] in ("HIGH", "MEDIUM"):
            buckets[m]["flagged"] += 1
    return {"items": [{"month": k, **v} for k, v in sorted(buckets.items())]}


@app.get("/api/v1/inspection-queue")
def inspection_queue(district: str | None = None, limit: int = 50):
    """The District Magistrate's view: what to inspect, in order."""
    rows = [r for r in STATE["rows"] if r["overall_risk_score"] > 0]
    if district:
        rows = [r for r in rows if r["district"] == district]
    rows.sort(key=lambda r: (-r["overall_risk_score"], -r["amount_at_risk"]))
    return {"total": len(rows), "items": [{
        "rank": i + 1, "project_id": r["project_id"], "score": r["overall_risk_score"],
        "band": r["risk_band"], "district": r["district"], "gp": r["gram_panchayat"],
        "amount_at_risk": r["amount_at_risk"], "ia_name": r["ia_name"],
        "flags": [a["type"] for a in r["anomalies"]], "disposition": r["disposition"],
    } for i, r in enumerate(rows[:limit])]}


@app.get("/api/v1/pre-sanction-check")
def pre_sanction_check(description: str, latitude: float, longitude: float,
                       category: str, district: str, amount: int, quantity: float):
    """
    THE GATE. Called by the sanctioning screen BEFORE money is committed.
    Returns an advisory verdict in a single round trip - this is the demo moment
    that separates prevention from post-mortem reporting.
    """
    from sentinel.config import DISTRICT_COST_INDEX, SOR_RATES
    from sentinel.engines.duplicate import haversine_m
    from sentinel.normalize import semantic_core
    from rapidfuzz import fuzz

    core = semantic_core(description)
    hits = []
    for p in STATE["projects"]:
        if p["work_category"] != category.upper():
            continue
        d = haversine_m(latitude, longitude, p["latitude"], p["longitude"])
        if d > 250:
            continue
        sim = fuzz.token_set_ratio(core, semantic_core(p["work_description"])) / 100.0
        if sim >= 0.62:
            hits.append({"project_id": p["project_id"], "distance_m": round(d, 1),
                         "similarity": round(sim, 3), "status": p["status"],
                         "description": p["work_description"],
                         "sanctioned_amount": p["sanctioned_amount"]})
    hits.sort(key=lambda h: -h["similarity"])

    bench = SOR_RATES[category.upper()]["rate"] * DISTRICT_COST_INDEX.get(district, 1.0)
    ratio = (amount / quantity) / bench if quantity else 0

    reasons = []
    if hits:
        reasons.append(f"{len(hits)} similar work(s) already on record within 250 m")
    if ratio >= 1.7:
        reasons.append(f"estimate is {ratio:.2f}x the district Schedule of Rates")
    verdict = "BLOCK_AND_REVIEW" if (hits and ratio >= 1.7) else \
              "REVIEW_BEFORE_SANCTION" if (hits or ratio >= 1.7) else "CLEAR"
    return {"verdict": verdict, "reasons": reasons, "sor_ratio": round(ratio, 3),
            "sor_benchmark_per_unit": round(bench, 2), "matches": hits[:5],
            "normalised_core": core}


class Disposal(BaseModel):
    project_id: str
    decision: str          # SUBSTANTIATED | PARTLY | FALSE_POSITIVE
    officer: str
    remarks: str = ""


@app.post("/api/v1/disposal")
def record_disposal(d: Disposal):
    """Closes the loop. Appends to the ledger; never edits history."""
    if d.project_id not in STATE["packets"]:
        raise HTTPException(404, "No open flag for this project")
    entry = STATE["ledger"].append("DISPOSAL", d.project_id, {
        "decision": d.decision, "remarks": d.remarks}, actor=d.officer)
    STATE["packets"][d.project_id]["disposition"] = d.decision
    return {"recorded": True, "entry_hash": entry["entry_hash"],
            "chain": STATE["ledger"].verify()}


@app.get("/api/v1/ledger/verify")
def ledger_verify():
    return STATE["ledger"].verify()


@app.get("/api/v1/projects/{project_id}/dossier")
def get_dossier(project_id: str):
    pk = STATE["packets"].get(project_id)
    if not pk:
        raise HTTPException(404, "No findings to report for this project")
    head = STATE["ledger"].verify().get("head", "")
    path = dossier_mod.build(pk, head)
    return FileResponse(path, media_type="application/pdf",
                        filename=f"AUDIT_DOSSIER_{project_id}.pdf")
