"""
Bakes the pipeline output into a single self-contained dashboard.html.

Why inline the data instead of fetching from the API?
  Demo insurance. On finale day the venue wifi will be saturated and something
  will go wrong. dashboard.html opens by double-clicking it, with no server, no
  build step and no network - and it still shows the full scored corpus. The
  live API path (api/main.py) is the real product; this is the parachute.
  If Leaflet's CDN is unreachable the map degrades to an inline SVG scatter.

    python build_dashboard.py
"""
from __future__ import annotations

import json
from collections import defaultdict
from datetime import date
from pathlib import Path

from sentinel.config import DISTRICT_COST_INDEX, MARCH_RUSH_WINDOW_DAYS, SOR_RATES

ROOT = Path(__file__).resolve().parent
OUT, DASH = ROOT / "out", ROOT / "dashboard"

SLIM = ["project_id", "district", "gram_panchayat", "work_category", "work_description",
        "sanctioned_amount", "released_amount", "status", "latitude", "longitude",
        "overall_risk_score", "risk_band", "amount_at_risk", "mp_id", "ia_name",
        "sanction_date", "fy"]


def main():
    rows = json.loads((OUT / "scored_projects.json").read_text())
    packets = json.loads((OUT / "risk_packets.json").read_text())
    conc = json.loads((OUT / "concentration.json").read_text())
    kpi = json.loads((OUT / "kpi.json").read_text())

    slim = [[round(r[f], 6) if f in ("latitude", "longitude") else r[f] for f in SLIM]
            for r in rows]

    monthly = defaultdict(lambda: {"value": 0, "works": 0})
    for r in rows:
        m = r["sanction_date"][:7]
        monthly[m]["value"] += r["sanctioned_amount"]
        monthly[m]["works"] += 1
    timeline = []
    for m in sorted(monthly):
        y, mo = m.split("-")
        timeline.append({"month": m, **monthly[m],
                         "march": mo == "03"})

    # pick a real planted duplicate to power the "load a known duplicate" button
    demo = None
    for pid, pk in sorted(packets.items(), key=lambda kv: -kv[1]["overall_risk_score"]):
        dup = next((a for a in pk["anomalies"] if a["type"] == "DUPLICATE_WORK"), None)
        if dup:
            qty = next((r for r in rows if r["project_id"] == pid), None)
            demo = {
                "description": dup["evidence"]["this_description"],
                "latitude": pk["latitude"], "longitude": pk["longitude"],
                "category": pk["work_category"], "district": pk["district"],
                "amount": pk["sanctioned_amount"],
                "quantity": round(pk["sanctioned_amount"] /
                                  (SOR_RATES[pk["work_category"]]["rate"] *
                                   DISTRICT_COST_INDEX[pk["district"]]), 3),
                # this proposal is not yet on record, so its own row is excluded
                # from the corpus for the simulation
                "exclude_ids": [pid],
                "matched_project_id": dup["evidence"]["matched_project_id"],
            }
            break

    focus = max({r["district"] for r in rows},
                key=lambda d: sum(1 for r in rows if r["district"] == d and r["risk_band"] == "HIGH"))

    payload = {
        "fields": SLIM,
        "rows": slim,
        "packets": packets,
        "concentration": conc,
        "timeline": timeline,
        "ledger": kpi["ledger"],
        "runtime_ms": int(kpi["generated_at_ms"]),
        "sor": {k: v["rate"] for k, v in SOR_RATES.items()},
        "cost_index": DISTRICT_COST_INDEX,
        "march_window_days": MARCH_RUSH_WINDOW_DAYS,
        "demo_duplicate": demo,
        "focus_district": focus,
    }

    html = (DASH / "template.html").read_text()
    html = html.replace("/*__DATA__*/{}", json.dumps(payload, separators=(",", ":")))
    target = DASH / "dashboard.html"
    target.write_text(html, encoding="utf-8")
    print(f"wrote {target}  ({target.stat().st_size/1024:.0f} KB, "
          f"{len(slim)} works, {len(packets)} flagged)")


if __name__ == "__main__":
    main()
