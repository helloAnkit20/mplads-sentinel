"""
1-CLICK FORENSIC AUDIT DOSSIER  (owner: Member 3)

Converts an evidence packet into a PDF an officer can sign and send. The point
is that our output is not a dashboard screenshot - it is a document that fits
into the existing paper workflow of a District Magistrate's office.

Structure of the dossier:
  1. Header: project identity, amounts, agency, risk band + the non-guilt caveat
  2. Findings: each anomaly, its evidence table, and the guideline clause and
     CAG audit-para family it engages
  3. Comparative evidence: for duplicates, the two descriptions side by side
     with the normalised cores that made them match
  4. Verification checklist the field officer physically ticks on site
  5. Provenance block: engine version, run timestamp, ledger hash

    python -m sentinel.dossier MPLAD-2025-WB-01234
"""
from __future__ import annotations

import json
import sys
import textwrap
from datetime import datetime
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    HRFlowable, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
)

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "out"
ENGINE_VERSION = "MPLADS-Sentinel 1.0"

NAVY = colors.HexColor("#0F2A47")
RED = colors.HexColor("#B3261E")
AMBER = colors.HexColor("#B26A00")
GREY = colors.HexColor("#5A6672")
LIGHT = colors.HexColor("#EEF1F5")

BAND_COLOR = {"HIGH": RED, "MEDIUM": AMBER, "LOW": GREY}

CHECKLISTS = {
    "DUPLICATE_WORK": [
        "Physically verify whether ONE asset or TWO distinct assets exist at the cited coordinates.",
        "Obtain the completion certificate and measurement book of the earlier work.",
        "Confirm whether the earlier asset was funded under MPLADS or another scheme.",
        "Record GPS coordinates and photographs of the asset from two angles.",
    ],
    "COST_OVERRUN": [
        "Obtain the detailed estimate and confirm the Schedule of Rates year applied.",
        "Verify measured quantities against the measurement book.",
        "Check whether any non-schedule item rates were approved, and by whom.",
        "Confirm whether the work was tendered and how many bids were received.",
    ],
    "SPLIT_TENDER": [
        "Establish whether the clustered works constitute one continuous work.",
        "Obtain all sanction orders in the cluster and identify the sanctioning authority.",
        "Verify whether the combined value crossed the tender/approval threshold.",
        "Record the tender process, if any, followed for each component.",
    ],
    "GHOST_ASSET": [
        "Conduct a physical site inspection and photograph the asset with live GPS capture.",
        "Compare the submitted completion photograph against the site as it stands.",
        "Obtain the vendor payment file and identify the officer who certified completion.",
        "Verify the asset is in public use as required by the guidelines.",
    ],
    "STALLED_WORK": [
        "Establish the current physical progress percentage on site.",
        "Confirm the amount released and the unspent balance lying with the agency.",
        "Record the reason for stoppage and identify the responsible agency.",
        "Determine whether recovery or re-tendering is required.",
    ],
    "INELIGIBLE_WORK": [
        "Obtain the land ownership record (khatian / mutation certificate) for the site.",
        "Confirm whether the asset is under the control of a public authority.",
        "Verify that the work falls within the list of permissible works.",
        "Identify the officer who certified eligibility at sanction stage.",
    ],
    "MARCH_RUSH": [
        "Verify the date of technical sanction against the date of administrative approval.",
        "Confirm whether estimates were appraised or approved in bulk.",
        "Check physical progress achieved against funds committed in the window.",
    ],
}


def _styles():
    ss = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("t", parent=ss["Title"], fontSize=16, leading=19,
                                textColor=NAVY, spaceAfter=2),
        "sub": ParagraphStyle("s", parent=ss["Normal"], fontSize=8.5, textColor=GREY,
                              alignment=1, spaceAfter=8),
        "h2": ParagraphStyle("h2", parent=ss["Heading2"], fontSize=11.5, textColor=NAVY,
                             spaceBefore=10, spaceAfter=4),
        "h3": ParagraphStyle("h3", parent=ss["Heading3"], fontSize=10, textColor=NAVY,
                             spaceBefore=6, spaceAfter=3),
        "body": ParagraphStyle("b", parent=ss["Normal"], fontSize=9, leading=12.5,
                               alignment=TA_JUSTIFY),
        "small": ParagraphStyle("sm", parent=ss["Normal"], fontSize=7.8, leading=10,
                                textColor=GREY),
        "mono": ParagraphStyle("m", parent=ss["Normal"], fontName="Courier", fontSize=7.5,
                               leading=9.5),
        "caveat": ParagraphStyle("c", parent=ss["Normal"], fontSize=8.2, leading=11,
                                 textColor=colors.HexColor("#4A3A00")),
    }


def _kv_table(pairs, widths=(45 * mm, 125 * mm)):
    data = [[Paragraph(f"<b>{k}</b>", _styles()["small"]),
             Paragraph(str(v), _styles()["small"])] for k, v in pairs]
    t = Table(data, colWidths=widths)
    t.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("LINEBELOW", (0, 0), (-1, -2), 0.25, colors.HexColor("#D8DEE6")),
        ("BACKGROUND", (0, 0), (0, -1), LIGHT),
    ]))
    return t


def _rupees(v):
    try:
        return f"Rs {int(v):,}"
    except (TypeError, ValueError):
        return str(v)


def build(packet, ledger_head="", path=None):
    S = _styles()
    pid = packet["project_id"]
    path = Path(path or OUT / f"AUDIT_DOSSIER_{pid}.pdf")
    path.parent.mkdir(parents=True, exist_ok=True)

    doc = SimpleDocTemplate(str(path), pagesize=A4,
                            leftMargin=18 * mm, rightMargin=18 * mm,
                            topMargin=15 * mm, bottomMargin=15 * mm,
                            title=f"Audit Dossier {pid}")
    st = []
    st.append(Paragraph("FORENSIC AUDIT DOSSIER", S["title"]))
    st.append(Paragraph(
        "Members of Parliament Local Area Development Scheme (MPLADS) &nbsp;|&nbsp; "
        "Automatically generated risk dossier &nbsp;|&nbsp; For inspection use", S["sub"]))
    st.append(HRFlowable(width="100%", thickness=1.2, color=NAVY, spaceAfter=8))

    band = packet["risk_band"]
    hdr = Table([[
        Paragraph(f"<b>{pid}</b><br/><font size=8 color='#5A6672'>"
                  f"{packet['work_category'].replace('_',' ').title()} &nbsp;|&nbsp; "
                  f"{packet['gram_panchayat']}, {packet['district']}</font>", S["body"]),
        Paragraph(f"<b><font size=18 color='{BAND_COLOR[band]}'>"
                  f"{packet['overall_risk_score']}</font></b><br/>"
                  f"<font size=8 color='{BAND_COLOR[band]}'><b>{band} RISK</b></font>",
                  ParagraphStyle("r", parent=S["body"], alignment=2)),
    ]], colWidths=(120 * mm, 50 * mm))
    hdr.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                             ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    st.append(hdr)

    st.append(Paragraph(
        "<b>Caveat:</b> The risk score indicates <b>inspection priority</b> derived from data "
        "patterns. It is <b>not a finding of misconduct</b> against any Hon'ble Member of "
        "Parliament, official or agency. Every observation below must be verified by the "
        "competent authority before any action is initiated.", S["caveat"]))
    st.append(Spacer(1, 6))

    st.append(Paragraph("1. Project Particulars", S["h2"]))
    st.append(_kv_table([
        ("Work description", packet["work_description"]),
        ("Implementing agency", f"{packet['ia_name']} ({packet['ia_id']})"),
        ("Recommending MP (ref.)", packet["mp_id"]),
        ("Sanction date / FY", f"{packet['sanction_date']}  |  {packet['fy']}"),
        ("Sanctioned amount", _rupees(packet["sanctioned_amount"])),
        ("Amount released", _rupees(packet["released_amount"])),
        ("Current status", packet["status"]),
        ("Location", f"{packet['latitude']}, {packet['longitude']}"),
        ("Estimated amount at risk", f"<b>{_rupees(packet['amount_at_risk'])}</b>"),
    ]))

    st.append(Paragraph("2. Risk Score Decomposition", S["h2"]))
    st.append(Paragraph(
        "The score is additive with saturation across independent detectors; every point "
        "traces back to a named finding below.", S["small"]))
    rows = [["Finding", "Confidence", "Weight", "Points", "Severity"]]
    for a in packet["anomalies"]:
        rows.append([a["type"].replace("_", " ").title(), f"{a['confidence']:.2f}",
                     str(a["weight"]), f"{a['points']:.1f}", a["severity"]])
    t = Table(rows, colWidths=(60 * mm, 27 * mm, 22 * mm, 22 * mm, 39 * mm))
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#D8DEE6")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT]),
        ("PADDING", (0, 0), (-1, -1), 4),
    ]))
    st.append(t)

    st.append(Paragraph("3. Findings and Evidence", S["h2"]))
    for n, a in enumerate(packet["anomalies"], 1):
        block = [Paragraph(f"3.{n} &nbsp; {a['type'].replace('_',' ').title()} "
                           f"<font color='{BAND_COLOR.get(a['severity'], GREY)}'>"
                           f"({a['severity']})</font>", S["h3"]),
                 Paragraph(a["explanation"], S["body"]), Spacer(1, 3)]
        ev = [(k.replace("_", " ").title(),
               _rupees(v) if ("inr" in k or "amount" in k) else
               (", ".join(map(str, v)) if isinstance(v, list) else v))
              for k, v in a["evidence"].items() if v not in (None, "", [])]
        if ev:
            block.append(_kv_table(ev))
        block.append(Spacer(1, 3))
        block.append(Paragraph(
            f"<b>Guideline engaged:</b> {a['guideline_clause']}<br/>"
            f"<b>Audit precedent:</b> {a['cag_reference']}", S["small"]))
        block.append(Spacer(1, 7))
        st.append(KeepTogether(block))

    st.append(PageBreak())
    st.append(Paragraph("4. Field Verification Checklist", S["h2"]))
    st.append(Paragraph(
        "To be completed by the inspecting officer on site. Tick, sign and upload against "
        "this project reference.", S["small"]))
    st.append(Spacer(1, 4))
    seen = set()
    rows = [["", "Verification step", "Observed", "Remarks"]]
    for a in packet["anomalies"]:
        for item in CHECKLISTS.get(a["type"], []):
            if item in seen:
                continue
            seen.add(item)
            rows.append(["[  ]", Paragraph(item, S["small"]), "", ""])
    t = Table(rows, colWidths=(10 * mm, 95 * mm, 22 * mm, 43 * mm), repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#D8DEE6")),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("PADDING", (0, 0), (-1, -1), 5),
        ("MINROWHEIGHTS", (0, 1), (-1, -1), 11 * mm),
    ]))
    st.append(t)

    st.append(Spacer(1, 10))
    st.append(Paragraph("5. Disposal", S["h2"]))
    st.append(Table([["Disposal decision:", "[  ] Substantiated   [  ] Partly substantiated   "
                      "[  ] Not substantiated (false positive)"],
                     ["Inspecting officer:", "________________________     Date: ____________"],
                     ["Countersigned:", "________________________     Designation: ____________"]],
                    colWidths=(38 * mm, 132 * mm),
                    style=TableStyle([("FONTSIZE", (0, 0), (-1, -1), 8),
                                      ("TOPPADDING", (0, 0), (-1, -1), 6),
                                      ("BOTTOMPADDING", (0, 0), (-1, -1), 6)])))
    st.append(Paragraph(
        "A disposal recorded as <i>not substantiated</i> is returned to the detection engine "
        "as a labelled negative and is used to retune thresholds.", S["small"]))

    st.append(Spacer(1, 10))
    st.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor("#D8DEE6")))
    st.append(Paragraph(
        f"Provenance: {ENGINE_VERSION} &nbsp;|&nbsp; generated "
        f"{datetime.now().strftime('%d %b %Y %H:%M')} &nbsp;|&nbsp; "
        f"audit ledger head: {ledger_head[:32] or 'n/a'}...<br/>"
        f"This dossier is reproducible: re-running the engine on the same input data "
        f"regenerates it byte-for-byte except for the timestamp.", S["small"]))

    doc.build(st)
    return path


def main():
    packets = json.loads((OUT / "risk_packets.json").read_text())
    ledger_head = ""
    kpi_path = OUT / "kpi.json"
    if kpi_path.exists():
        ledger_head = json.loads(kpi_path.read_text()).get("ledger", {}).get("head", "")
    if len(sys.argv) > 1:
        targets = [sys.argv[1]]
    else:
        targets = [p["project_id"] for p in
                   sorted(packets.values(), key=lambda x: -x["overall_risk_score"])[:3]]
    for pid in targets:
        out = build(packets[pid], ledger_head)
        print(f"wrote {out}")


if __name__ == "__main__":
    main()
