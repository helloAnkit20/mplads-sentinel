"""
Synthetic MPLADS corpus generator with GROUND TRUTH labels.

Why synthetic at all, if e-SAKSHI has real data?
  Because the public e-SAKSHI dashboard exposes aggregates, not the
  project-level unit quantities, coordinates and IA identifiers our detectors
  need - and because we need LABELS to report precision and recall. We
  therefore generate a corpus whose *shape* mirrors the e-SAKSHI record
  structure, plant a known set of frauds, and measure against them.
  The loader in sentinel/schema.py accepts real e-SAKSHI exports in the same
  shape, so nothing changes when real data arrives.

Every planted fraud is written to data/ground_truth.csv so evaluate.py can
score the system honestly.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import random
from datetime import date, timedelta
from pathlib import Path

from .config import (
    DISTRICT_COST_INDEX,
    SANCTION_SPLIT_THRESHOLD,
    SPLIT_WINDOW_DAYS,
    SOR_RATES,
    STATE,
)

SEED = 20260826
DATA_DIR = Path(__file__).resolve().parent.parent / "data"

# ---------------------------------------------------------------------------
# Vocabulary. Deliberately messy: mixed English, transliterated Bengali/Hindi,
# inconsistent abbreviations - exactly what wrecks a naive string match and
# exactly why the normalizer in normalize.py exists.
# ---------------------------------------------------------------------------
DISTRICTS = {
    "Nadia":           (23.4710, 88.5565),
    "Purba Bardhaman": (23.2324, 87.8615),
    "Hooghly":         (22.9089, 88.3960),
    "Bankura":         (23.2324, 87.0716),
}

BLOCKS = ["Sadar", "Uttar", "Dakshin", "Purba", "Paschim"]
GP_NAMES = [
    "Ramnagar", "Sonapur", "Bishnupur", "Haripal", "Chandrakona", "Belgharia",
    "Mahisdal", "Kalyanpur", "Debipur", "Amgram", "Nutangram", "Baruipara",
    "Jagadishpur", "Simulia", "Panchgachia", "Rajarampur",
]

WORK_TEMPLATES = {
    "CC_ROAD": [
        "Construction of C.C. Road from {a} to {b} at {gp} G.P. Ward No {w}",
        "Nirman of concrete road at {gp}, Ward-{w} (from {a} upto {b})",
        "Improvement of village road by RCC at {gp} Gram Panchayat Ward {w}",
        "C C Road construction near {a}, {gp} GP, Ward no.{w}",
    ],
    "COMMUNITY_HALL": [
        "Construction of Community Hall at {gp} Gram Panchayat",
        "Samudayik Bhavan nirman at {gp} G.P. Ward No {w}",
        "Community centre building construction at {a}, {gp}",
    ],
    "SCHOOL_ROOM": [
        "Construction of {q} additional class room at {a} Primary School, {gp}",
        "Additional classroom nirman in {a} Pry School under {gp} GP",
        "Class room construction at {a} F.P. School, {gp} Gram Panchayat",
    ],
    "WATER_TANK": [
        "Construction of overhead water reservoir at {gp} Ward No {w}",
        "Peyojal overhead tank nirman at {a}, {gp} G.P.",
        "Drinking water tank with pump at {gp} Gram Panchayat, Ward-{w}",
    ],
    "SOLAR_LIGHT": [
        "Installation of solar street light at {gp} G.P. Ward No {w}",
        "Solar LED street lighting at {a} more, {gp}",
        "Supply and installation of {q} nos solar street light, {gp} GP",
    ],
    "DRAIN": [
        "Construction of pucca drain from {a} to {b} at {gp}",
        "Nala nirman (RCC drain) at {gp} Gram Panchayat Ward {w}",
        "Pucca drain construction near {a}, {gp} G.P.",
    ],
    "BOUNDARY_WALL": [
        "Construction of boundary wall of {a} School at {gp}",
        "School boundary wall nirman at {a}, {gp} Gram Panchayat",
        "Compound wall construction at {a} High School, {gp} GP",
    ],
    "TOILET_BLOCK": [
        "Construction of sanitary toilet block at {a} School, {gp}",
        "Shauchalay nirman ({q} seat) at {gp} G.P.",
        "Toilet block with water connection at {a}, {gp}",
    ],
}

LANDMARKS = [
    "Bazar More", "Post Office", "Panchayat Office", "Kali Mandir Road",
    "Health Sub Centre", "Bus Stand", "Primary School", "Rail Gate",
    "Sarkari Pukur", "Krishi Office", "Club Ground", "Bridge Point",
]

IA_TYPES = ["PRI", "PWD", "MUNICIPALITY", "SOCIETY", "ZILLA_PARISHAD"]
IA_BASE_NAMES = [
    "Gram Panchayat", "Panchayat Samiti", "Zilla Parishad", "PWD Rural Division",
    "Municipality Engg Cell", "Rural Works Dept", "Sthaniya Nirman Samiti",
]

STATUSES = ["RECOMMENDED", "SANCTIONED", "IN_PROGRESS", "COMPLETED"]


def _rng():
    return random.Random(SEED)


def _jitter(lat, lon, km, rng):
    """Offset a coordinate by up to `km` kilometres in a random direction."""
    r = km * math.sqrt(rng.random())
    theta = rng.random() * 2 * math.pi
    dlat = (r / 111.32) * math.cos(theta)
    dlon = (r / (111.32 * math.cos(math.radians(lat)))) * math.sin(theta)
    return round(lat + dlat, 6), round(lon + dlon, 6)


def _photo_hash(seed_text: str) -> str:
    """Stand-in for a perceptual hash of the completion photograph."""
    return hashlib.sha1(seed_text.encode()).hexdigest()[:16]


def _quantity(cat, rng):
    if cat == "CC_ROAD":
        return round(rng.uniform(0.15, 0.9), 3)
    if cat == "COMMUNITY_HALL":
        return round(rng.uniform(60, 220), 1)
    if cat == "SCHOOL_ROOM":
        return rng.randint(1, 4)
    if cat == "WATER_TANK":
        return rng.choice([5, 8, 10, 15, 20, 25])
    if cat == "SOLAR_LIGHT":
        return rng.randint(6, 40)
    if cat == "DRAIN":
        return rng.randint(80, 600)
    if cat == "BOUNDARY_WALL":
        return rng.randint(60, 400)
    return rng.randint(2, 8)  # TOILET_BLOCK seats


def _fy_of(d: date) -> str:
    return f"{d.year}-{str(d.year + 1)[2:]}" if d.month >= 4 else f"{d.year - 1}-{str(d.year)[2:]}"


def _make_description(cat, gp, rng, qty):
    tpl = rng.choice(WORK_TEMPLATES[cat])
    return tpl.format(
        a=rng.choice(LANDMARKS),
        b=rng.choice(LANDMARKS),
        gp=gp,
        w=rng.randint(1, 17),
        q=int(qty) if qty == int(qty) else qty,
    )


def build_corpus(n_clean=2400):
    rng = _rng()
    rows = []
    truth = []           # (project_id, fraud_type)
    mp_ids = []
    for i, d in enumerate(DISTRICTS):
        mp_ids.append(f"MP-LS-{d[:3].upper()}-{i+1:02d}")
    ia_registry = []
    for d in DISTRICTS:
        for j in range(9):
            ia_registry.append({
                "ia_id": f"IA-{d[:3].upper()}-{j+1:03d}",
                "ia_name": f"{rng.choice(GP_NAMES)} {rng.choice(IA_BASE_NAMES)}",
                "ia_type": rng.choices(IA_TYPES, weights=[45, 15, 12, 13, 15])[0],
                "district": d,
            })

    start_window = date(2023, 4, 1)
    end_window = date(2026, 3, 20)
    span = (end_window - start_window).days

    def new_project(idx, district, cat=None, gp=None, base_ll=None, ia=None,
                    sanction_date=None, unit_cost_mult=1.0, status=None,
                    qty=None, photo_seed=None, land=None):
        cat = cat or rng.choice(list(SOR_RATES))
        gp = gp or rng.choice(GP_NAMES)
        dlat, dlon = DISTRICTS[district]
        lat, lon = base_ll or _jitter(dlat, dlon, 28, rng)
        ia = ia or rng.choice([x for x in ia_registry if x["district"] == district])
        rec = sanction_date or (start_window + timedelta(days=rng.randint(0, span)))
        sanc = rec + timedelta(days=rng.randint(12, 75))
        qty = qty if qty is not None else _quantity(cat, rng)
        sor = SOR_RATES[cat]["rate"] * DISTRICT_COST_INDEX[district]
        # honest projects scatter tightly around SoR
        noise = rng.gauss(1.0, 0.11)
        amount = int(qty * sor * max(0.7, noise) * unit_cost_mult)
        planned_days = rng.randint(120, 330)
        st = status or rng.choices(STATUSES, weights=[6, 16, 30, 48])[0]
        start = sanc + timedelta(days=rng.randint(5, 60)) if st in ("IN_PROGRESS", "COMPLETED") else None
        completed = None
        last_update = sanc
        if st == "COMPLETED":
            completed = (start or sanc) + timedelta(days=int(planned_days * rng.uniform(0.7, 1.35)))
            if completed > end_window:
                completed = end_window
            last_update = completed
        elif st in ("SANCTIONED", "RECOMMENDED"):
            if (end_window - sanc).days > planned_days * 0.9:
                sanc = end_window - timedelta(days=rng.randint(10, int(planned_days * 0.8)))
                rec = sanc - timedelta(days=rng.randint(12, 60))
            last_update = sanc
        elif st == "IN_PROGRESS":
            # an honest live work reports progress recently; the gap between
            # sanction and now stays inside roughly one planned duration
            if (end_window - sanc).days > planned_days * 1.4:
                sanc = end_window - timedelta(days=rng.randint(40, int(planned_days * 1.2)))
                start = sanc + timedelta(days=rng.randint(5, 40))
            last_update = end_window - timedelta(days=rng.randint(5, 120))
        if last_update > end_window:
            last_update = end_window
        released = amount if st == "COMPLETED" else int(amount * rng.uniform(0.0, 0.6))
        pid = f"MPLAD-{_fy_of(sanc)[:4]}-WB-{idx:05d}"
        return {
            "project_id": pid,
            "mp_id": mp_ids[list(DISTRICTS).index(district)],
            "house": "LOK_SABHA",
            "state": STATE,
            "district": district,
            "block": rng.choice(BLOCKS),
            "gram_panchayat": gp,
            "ward_no": rng.randint(1, 17),
            "work_category": cat,
            "work_description": _make_description(cat, gp, rng, qty),
            "physical_quantity": qty,
            "unit": SOR_RATES[cat]["unit"],
            "sanctioned_amount": amount,
            "released_amount": released,
            "latitude": lat,
            "longitude": lon,
            "ia_id": ia["ia_id"],
            "ia_name": ia["ia_name"],
            "ia_type": ia["ia_type"],
            "land_tenure": land or rng.choices(
                ["PUBLIC", "PANCHAYAT", "GOVT_SCHOOL"], weights=[52, 26, 22])[0],
            "recommendation_date": rec.isoformat(),
            "sanction_date": sanc.isoformat(),
            "start_date": start.isoformat() if start else "",
            "planned_duration_days": planned_days,
            "completion_date": completed.isoformat() if completed else "",
            "last_update_date": last_update.isoformat(),
            "status": st,
            "fy": _fy_of(sanc),
            "completion_photo_hash": _photo_hash(photo_seed or pid) if st == "COMPLETED" else "",
            "sc_area": rng.random() < 0.22,
            "st_area": rng.random() < 0.09,
        }

    idx = 1
    for _ in range(n_clean):
        d = rng.choice(list(DISTRICTS))
        rows.append(new_project(idx, d))
        idx += 1

    by_id = {r["project_id"]: r for r in rows}

    # ---------------- planted fraud ----------------

    # 1. DUPLICATE_WORK - same asset re-billed with a rephrased description
    #    at a coordinate a few dozen metres away, in a later financial year.
    donors = rng.sample([r for r in rows if r["status"] == "COMPLETED"], 14)
    for donor in donors:
        clone = new_project(
            idx, donor["district"], cat=donor["work_category"],
            gp=donor["gram_panchayat"],
            base_ll=_jitter(donor["latitude"], donor["longitude"], 0.06, rng),
            qty=donor["physical_quantity"],
            sanction_date=date.fromisoformat(donor["sanction_date"]) + timedelta(days=rng.randint(210, 620)),
        )
        clone["work_description"] = _rephrase(donor["work_description"], rng)
        rows.append(clone)
        truth.append((clone["project_id"], "DUPLICATE_WORK"))
        idx += 1

    # 2. COST_OVERRUN - unit rate far above district SoR
    for _ in range(14):
        d = rng.choice(list(DISTRICTS))
        p = new_project(idx, d, unit_cost_mult=rng.uniform(1.9, 3.4))
        rows.append(p)
        truth.append((p["project_id"], "COST_OVERRUN"))
        idx += 1

    # 3. SPLIT_TENDER - one big work broken into N pieces just below the
    #    sanction threshold, same IA, same GP, same fortnight.
    for _ in range(5):
        d = rng.choice(list(DISTRICTS))
        ia = rng.choice([x for x in ia_registry if x["district"] == d])
        gp = rng.choice(GP_NAMES)
        base = date(2024, 3, 1) + timedelta(days=rng.randint(0, 600))
        dlat, dlon = DISTRICTS[d]
        anchor = _jitter(dlat, dlon, 20, rng)
        for k in range(rng.randint(4, 6)):
            cat = "DRAIN" if rng.random() < 0.5 else "CC_ROAD"
            sor = SOR_RATES[cat]["rate"] * DISTRICT_COST_INDEX[d]
            target = SANCTION_SPLIT_THRESHOLD * rng.uniform(0.88, 0.985)
            qty = round(target / sor, 3) if cat == "CC_ROAD" else max(1, int(target / sor))
            p = new_project(
                idx, d, cat=cat, gp=gp, ia=ia, qty=qty,
                base_ll=_jitter(anchor[0], anchor[1], 0.3, rng),
                sanction_date=base + timedelta(days=rng.randint(0, 11)),
            )
            p["sanctioned_amount"] = int(target)
            sd = base + timedelta(days=rng.randint(0, SPLIT_WINDOW_DAYS - 3))
            p["sanction_date"] = sd.isoformat()
            p["recommendation_date"] = (sd - timedelta(days=rng.randint(15, 40))).isoformat()
            p["fy"] = _fy_of(sd)
            rows.append(p)
            truth.append((p["project_id"], "SPLIT_TENDER"))
            idx += 1

    # 4. GHOST_ASSET - marked COMPLETED but the "site photograph" is a
    #    re-upload of a photo already used on a different project.
    photo_donors = rng.sample([r for r in rows if r["status"] == "COMPLETED"], 10)
    for donor in photo_donors:
        d = rng.choice(list(DISTRICTS))
        p = new_project(idx, d, status="COMPLETED")
        p["completion_photo_hash"] = donor["completion_photo_hash"]
        p["released_amount"] = p["sanctioned_amount"]
        donor_done = date.fromisoformat(donor["completion_date"])
        p["completion_date"] = (donor_done + timedelta(days=rng.randint(45, 300))).isoformat()
        p["last_update_date"] = p["completion_date"]
        rows.append(p)
        truth.append((p["project_id"], "GHOST_ASSET"))
        idx += 1

    # 5. STALLED_WORK - sanctioned, money partly released, then silence.
    for _ in range(12):
        d = rng.choice(list(DISTRICTS))
        sd = date(2023, 5, 1) + timedelta(days=rng.randint(0, 260))
        p = new_project(idx, d, status="IN_PROGRESS", sanction_date=sd)
        # override AFTER construction: the helper pulls honest in-progress works
        # forward in time, and a planted stall must keep its original old date
        p["recommendation_date"] = sd.isoformat()
        p["sanction_date"] = (sd + timedelta(days=rng.randint(12, 40))).isoformat()
        p["start_date"] = (sd + timedelta(days=rng.randint(45, 70))).isoformat()
        p["last_update_date"] = (sd + timedelta(days=rng.randint(50, 110))).isoformat()
        p["planned_duration_days"] = rng.randint(120, 200)
        p["fy"] = _fy_of(sd)
        rows.append(p)
        truth.append((p["project_id"], "STALLED_WORK"))
        idx += 1

    # 6. INELIGIBLE_WORK - asset created on private / religious land.
    for _ in range(8):
        d = rng.choice(list(DISTRICTS))
        p = new_project(idx, d, land=rng.choice(["PRIVATE", "RELIGIOUS"]))
        rows.append(p)
        truth.append((p["project_id"], "INELIGIBLE_WORK"))
        idx += 1

    # 7. MARCH_RUSH - a burst of high-value sanctions in the last days of March.
    rush_plan = [("Hooghly", 2025, 6), ("Bankura", 2024, 5)]
    for d, yr, count in rush_plan:
      for _ in range(count):
        sd = date(yr, 3, rng.randint(22, 31))
        p = new_project(idx, d, sanction_date=sd - timedelta(days=20))
        p["sanction_date"] = sd.isoformat()
        p["recommendation_date"] = (sd - timedelta(days=rng.randint(6, 20))).isoformat()
        infl = rng.uniform(1.6, 2.4)
        p["sanctioned_amount"] = int(p["sanctioned_amount"] * infl)
        q = p["physical_quantity"] * infl
        p["physical_quantity"] = round(q, 3) if isinstance(p["physical_quantity"], float) else max(1, int(q))
        p["fy"] = _fy_of(sd)
        rows.append(p)
        truth.append((p["project_id"], "MARCH_RUSH"))
        idx += 1

    return rows, truth


def _rephrase(desc: str, rng) -> str:
    """
    Turn a description into a near-synonym the way a contractor would when
    re-billing the same work. This is what defeats exact and LIKE matching.
    """
    swaps = [
        ("Construction of", "Nirman of"), ("Construction", "Nirman karya"),
        ("C.C. Road", "Concrete Road"), ("CC Road", "C C Rd"),
        ("Road", "Rasta"), ("Gram Panchayat", "G.P."), ("G.P.", "Gram Panchyat"),
        ("Ward No", "Ward-"), ("School", "Vidyalaya"), ("Community Hall", "Samudayik Bhavan"),
        ("drain", "nala"), ("Drain", "Nala"), ("water", "peyojal"),
        ("boundary wall", "compound wall"), ("Installation of", "Supply & fixing of"),
        ("at", "near"), ("from", "starting from"),
    ]
    out = desc
    rng.shuffle(swaps)
    applied = 0
    for a, b in swaps:
        if a in out and applied < 3:
            out = out.replace(a, b, 1)
            applied += 1
    if rng.random() < 0.5:
        out = out + " (Phase-II)"
    return out


def main():
    DATA_DIR.mkdir(exist_ok=True)
    rows, truth = build_corpus()
    fields = list(rows[0].keys())
    with open(DATA_DIR / "projects.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    with open(DATA_DIR / "ground_truth.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["project_id", "fraud_type"])
        w.writerows(truth)
    summary = {
        "total_projects": len(rows),
        "planted_frauds": len(truth),
        "districts": list(DISTRICTS),
        "total_sanctioned_inr": sum(r["sanctioned_amount"] for r in rows),
        "by_fraud_type": {t: sum(1 for _, x in truth if x == t) for t in sorted({x for _, x in truth})},
    }
    (DATA_DIR / "corpus_summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
