"""
Pipeline orchestrator. One entry point, runs everything, writes out/.

    python -m sentinel.pipeline
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from .engines import cost, duplicate, integrity, structuring
from .risk import AuditLedger, aggregate, score_all
from .schema import load_projects

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
OUT = ROOT / "out"


def run_all(projects, verbose=True):
    timings, findings = {}, []
    stages = [
        ("duplicate", lambda: duplicate.run(projects)),
        ("cost", lambda: cost.run(projects)),
        ("structuring", lambda: structuring.run(projects)),
        ("stalled", lambda: integrity.stalled(projects)),
        ("ghost_asset", lambda: integrity.ghost_assets(projects)),
        ("compliance", lambda: integrity.compliance(projects)),
        ("march_rush", lambda: integrity.march_rush(projects)),
    ]
    for name, fn in stages:
        t0 = time.perf_counter()
        got = fn()
        dt = (time.perf_counter() - t0) * 1000
        timings[name] = round(dt, 1)
        findings.extend(got)
        if verbose:
            print(f"  {name:<14} {len(got):>4} findings   {dt:8.1f} ms")
    return findings, timings


def main():
    OUT.mkdir(exist_ok=True)
    projects = load_projects(DATA / "projects.csv")
    print(f"Loaded {len(projects)} projects\n")
    print("Running detection engines:")
    t0 = time.perf_counter()
    findings, timings = run_all(projects)
    total_ms = (time.perf_counter() - t0) * 1000

    packets = aggregate(projects, findings)
    all_rows = score_all(projects, packets)

    # tamper-evident ledger
    ledger = AuditLedger(OUT / "ledger.jsonl")
    if (OUT / "ledger.jsonl").exists():
        (OUT / "ledger.jsonl").unlink()
    for pid, pk in sorted(packets.items()):
        if pk["risk_band"] in ("HIGH", "MEDIUM"):
            ledger.append("FLAG_RAISED", pid, {
                "score": pk["overall_risk_score"],
                "types": [a["type"] for a in pk["anomalies"]],
            })

    concentration = structuring.concentration_report(projects)

    high = [r for r in all_rows if r["risk_band"] == "HIGH"]
    med = [r for r in all_rows if r["risk_band"] == "MEDIUM"]
    kpi = {
        "generated_at_ms": round(total_ms, 1),
        "engine_timings_ms": timings,
        "total_projects": len(projects),
        "total_sanctioned_inr": sum(p["sanctioned_amount"] for p in projects),
        "total_released_inr": sum(p["released_amount"] for p in projects),
        "flagged_projects": len(packets),
        "high_risk": len(high),
        "medium_risk": len(med),
        "exposure_flagged_inr": sum(r["amount_at_risk"] for r in all_rows),
        "exposure_high_risk_inr": sum(r["amount_at_risk"] for r in high),
        "findings_by_type": {t: sum(1 for f in findings if f["type"] == t)
                             for t in sorted({f["type"] for f in findings})},
        "captured_panchayats": sum(1 for c in concentration if c["concentration_band"] == "CAPTURED"),
        "ledger": ledger.verify(),
    }

    (OUT / "findings.json").write_text(json.dumps(findings, indent=2))
    (OUT / "risk_packets.json").write_text(json.dumps(packets, indent=2))
    (OUT / "scored_projects.json").write_text(json.dumps(all_rows, indent=2))
    (OUT / "concentration.json").write_text(json.dumps(concentration, indent=2))
    (OUT / "kpi.json").write_text(json.dumps(kpi, indent=2))

    print(f"\nTotal pipeline: {total_ms:.0f} ms for {len(projects)} projects")
    print(f"HIGH {len(high)}   MEDIUM {len(med)}   "
          f"exposure Rs {kpi['exposure_flagged_inr']:,}")
    print(f"Ledger: {kpi['ledger']}")
    return kpi


if __name__ == "__main__":
    main()
