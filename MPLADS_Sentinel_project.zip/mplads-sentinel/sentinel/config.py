"""
MPLADS SENTINEL - central configuration.

Every threshold in this file is a POLICY KNOB, not a magic number.
Judges will ask "why 0.82?" - the answer must be "it is tuned on the
labelled set, and here is the precision/recall curve" (see evaluate.py),
not "the tutorial said so".
"""

# ----------------------------------------------------------------------------
# Schedule of Rates (SoR) benchmark.
# In production these are read from the State PWD Schedule of Rates PDF for the
# relevant financial year. Rates are in INR per unit of physical quantity.
# This is the single most important idea in the cost engine: an auditor does not
# ask "is this invoice weird", they ask "what does a km of CC road cost in THIS
# district THIS year, and is this project paying more than that".
# ----------------------------------------------------------------------------
SOR_RATES = {
    "CC_ROAD":       {"unit": "km",        "rate": 11_000_000},
    "COMMUNITY_HALL":{"unit": "sqm",       "rate": 18_500},
    "SCHOOL_ROOM":   {"unit": "room",      "rate": 900_000},
    "WATER_TANK":    {"unit": "kilolitre", "rate": 22_000},
    "SOLAR_LIGHT":   {"unit": "pole",      "rate": 28_000},
    "DRAIN":         {"unit": "metre",     "rate": 3_500},
    "BOUNDARY_WALL": {"unit": "metre",     "rate": 4_200},
    "TOILET_BLOCK":  {"unit": "seat",      "rate": 85_000},
}

# District cost index - real SoR varies by district (haulage, quarry distance).
DISTRICT_COST_INDEX = {
    "Nadia":            1.00,
    "Purba Bardhaman":  0.94,
    "Hooghly":          1.06,
    "Bankura":          0.91,
}

STATE = "West Bengal"

# ----------------------------------------------------------------------------
# Detection thresholds
# ----------------------------------------------------------------------------

# --- Duplicate engine ---
DUP_GEO_RADIUS_M       = 150.0   # spatial buffer; ST_DWithin equivalent
DUP_TEXT_SIM_MIN       = 0.62    # blended text similarity floor
DUP_HARD_FLAG_SIM      = 0.78    # above this + inside radius = high confidence
DUP_MIN_DAYS_APART     = 30      # phased works legitimately repeat; ignore <30d

# --- Cost engine ---
COST_SOR_RATIO_WARN    = 1.35    # 35% above district SoR = warn
COST_SOR_RATIO_FLAG    = 1.70    # 70% above = flag
COST_ROBUST_Z_FLAG     = 3.5     # modified z-score vs peer group (MAD based)

# --- Structuring / split-tender engine ---
# Works above this value require a higher approval authority, so the classic
# evasion is to break one big work into several just below the line.
SANCTION_SPLIT_THRESHOLD = 500_000
SPLIT_WINDOW_DAYS        = 14
SPLIT_MIN_WORKS          = 3
SPLIT_PROXIMITY_BAND     = 0.85  # each work must be >=85% of threshold to count

# --- Stall engine ---
STALL_NO_UPDATE_DAYS   = 270     # 9 months of silence on an in-progress work
STALL_OVERDUE_FACTOR   = 1.5     # elapsed > 1.5x planned duration

# --- March rush ---
MARCH_RUSH_WINDOW_DAYS = 12      # last N days of the financial year
MARCH_RUSH_SHARE_FLAG  = 0.18    # share of a district's annual sanction value
MARCH_RUSH_RATE_RATIO  = 4.0     # OR: rupees/day in window vs rupees/day rest of year

# --- Risk aggregation weights (sum need not be 1; score is capped at 100) ---
# Weight = the risk score a SINGLE finding of this type produces at
# confidence 1.0. Calibrated so that any one definitive finding (a reused
# completion photograph, a confirmed duplicate, an asset on private land)
# lands in the HIGH band on its own, while soft signals (a stalled work, a
# March bunching) need corroboration before they reach an officer's queue.
RISK_WEIGHTS = {
    "GHOST_ASSET":     85,
    "DUPLICATE_WORK":  78,
    "INELIGIBLE_WORK": 76,
    "COST_OVERRUN":    58,
    "SPLIT_TENDER":    58,
    "STALLED_WORK":    50,
    "MARCH_RUSH":      22,
}

RISK_BANDS = [(65, "HIGH"), (35, "MEDIUM"), (0, "LOW")]

# ----------------------------------------------------------------------------
# Legal hooks. This is what turns a "score" into something an officer can act
# on. Every flag we raise cites the guideline clause it offends and the CAG
# audit paragraph family that historically covers it.
# NOTE FOR THE TEAM: clause numbers below are placeholders keyed to the
# structure of the MPLADS Guidelines (revised w.e.f. 01-04-2023). Before the
# finale, open the official guidelines PDF on mplads.mospi.gov.in and replace
# each string with the exact clause number. Judges from MoSPI will know these.
# ----------------------------------------------------------------------------
LEGAL_HOOKS = {
    "DUPLICATE_WORK": {
        "clause": "MPLADS Guidelines 2023 - Ch. 3 (Eligible Works): a work already "
                  "executed under any scheme shall not be re-sanctioned",
        "cag": "CAG Performance Audit (Report No. 31 of 2010-11) - duplication of "
               "works already covered under other schemes",
    },
    "COST_OVERRUN": {
        "clause": "MPLADS Guidelines 2023 - Ch. 6 (Sanction): estimates to be "
                  "prepared as per the State Schedule of Rates",
        "cag": "CAG - excess/inflated estimates and undue benefit to agencies",
    },
    "SPLIT_TENDER": {
        "clause": "GFR 2017 R.166/R.173 read with MPLADS sanction powers: splitting "
                  "of works to avoid the prescribed approval or tender limit",
        "cag": "CAG - award of works without tender / splitting to bypass limits",
    },
    "GHOST_ASSET": {
        "clause": "MPLADS Guidelines 2023 - payment on upload of proof of completion; "
                  "asset must physically exist and be in public use",
        "cag": "CAG - works shown complete but not existing / not put to public use",
    },
    "STALLED_WORK": {
        "clause": "MPLADS Guidelines 2023 - Ch. 7: works to be completed within the "
                  "prescribed time; incomplete works to be reported",
        "cag": "CAG - works incomplete/abandoned for years, funds parked with IAs",
    },
    "INELIGIBLE_WORK": {
        "clause": "MPLADS Guidelines 2023 - Ch. 3 & Annexure of prohibited works: "
                  "no assets on private/religious/trust land for private benefit",
        "cag": "CAG - assets created on private land / ineligible works sanctioned",
    },
    "MARCH_RUSH": {
        "clause": "MPLADS Guidelines 2023 - funds are non-lapsable; end-of-year "
                  "bunching defeats appraisal and quality control",
        "cag": "CAG - rush of expenditure in March without quality assurance",
    },
}

# Ineligible land tenure per guidelines
INELIGIBLE_LAND = {"PRIVATE", "RELIGIOUS", "TRUST_PRIVATE"}

# Guidelines prefer Panchayati Raj Institutions as Implementing Agency
PREFERRED_IA_TYPES = {"PRI", "MUNICIPALITY"}
