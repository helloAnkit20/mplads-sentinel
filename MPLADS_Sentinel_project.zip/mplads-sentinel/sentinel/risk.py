"""
RISK AGGREGATOR + TAMPER-EVIDENT AUDIT TRAIL  (owner: Member 3)

Turns raw engine findings into an EVIDENCE PACKET - the unit of work an
officer actually consumes.

Design rules we can defend in Q&A:

 1. A risk score is a PRIORITISATION, not a finding of guilt. The UI says so,
    the dossier says so, and we say so in the pitch. This is what stops the
    "you are accusing an MP" question from killing us.

 2. Scores are additive-with-saturation, not multiplicative and not learned:
        score = 100 * (1 - product over findings of (1 - w_i * confidence_i / 100))
    Every point on the score decomposes back to a named finding, so we can
    always answer "why 88?" with a list, not a shrug.

 3. Every finding carries a LEGAL HOOK (guideline clause + CAG audit para
    family). A flag without a clause is a rumour; a flag with a clause is an
    inspection order.

 4. Every flag written is appended to a hash-chained ledger. Each entry stores
    the SHA-256 of the previous entry, so any later edit or deletion breaks the
    chain and is provable. This is what makes the output admissible for a
    vigilance enquiry and it answers "what if an official quietly deletes an
    inconvenient flag?".

 5. Disposal loop: a flag moves OPEN -> UNDER_REVIEW -> DISPOSED with an
    officer's reason code. Disposals labelled FALSE_POSITIVE are exported as
    training labels for threshold retuning. Nobody else in the room will have
    built the loop that closes.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

from .config import LEGAL_HOOKS, RISK_BANDS, RISK_WEIGHTS


def band(score):
    for cutoff, name in RISK_BANDS:
        if score >= cutoff:
            return name
    return "LOW"


def aggregate(projects, findings):
    """Return {project_id: evidence_packet}."""
    by_project = {}
    for f in findings:
        by_project.setdefault(f["project_id"], []).append(f)

    index = {p["project_id"]: p for p in projects}
    packets = {}

    for pid, fs in by_project.items():
        p = index.get(pid)
        if p is None:
            continue
        surv = 1.0
        for f in fs:
            w = RISK_WEIGHTS.get(f["type"], 10) / 100.0
            surv *= (1.0 - w * f["confidence"])
        score = int(round(100 * (1 - surv)))

        contributions = []
        for f in sorted(fs, key=lambda x: -RISK_WEIGHTS.get(x["type"], 0) * x["confidence"]):
            w = RISK_WEIGHTS.get(f["type"], 10)
            contributions.append({
                "type": f["type"],
                "confidence": f["confidence"],
                "severity": f["severity"],
                "weight": w,
                "points": round(w * f["confidence"], 1),
                "explanation": f["explanation"],
                "evidence": f["evidence"],
                "guideline_clause": LEGAL_HOOKS.get(f["type"], {}).get("clause", ""),
                "cag_reference": LEGAL_HOOKS.get(f["type"], {}).get("cag", ""),
            })

        amount_at_risk = max(
            [c["evidence"].get("amount_at_risk", 0) for c in contributions] +
            [c["evidence"].get("estimated_excess_inr", 0) for c in contributions] +
            [c["evidence"].get("funds_released_inr", 0) for c in contributions] +
            [c["evidence"].get("amount_released_inr", 0) for c in contributions] + [0]
        )

        packets[pid] = {
            "project_id": pid,
            "overall_risk_score": score,
            "risk_band": band(score),
            "district": p["district"],
            "gram_panchayat": p["gram_panchayat"],
            "work_category": p["work_category"],
            "work_description": p["work_description"],
            "sanctioned_amount": p["sanctioned_amount"],
            "released_amount": p["released_amount"],
            "status": p["status"],
            "ia_name": p["ia_name"],
            "ia_id": p["ia_id"],
            "mp_id": p["mp_id"],
            "latitude": p["latitude"],
            "longitude": p["longitude"],
            "sanction_date": p["sanction_date"],
            "fy": p["fy"],
            "amount_at_risk": int(amount_at_risk),
            "anomalies": contributions,
            "disposition": "OPEN",
            "disclaimer": (
                "Risk score indicates inspection priority based on data patterns. "
                "It is not a finding of misconduct and must be verified by the "
                "competent authority before any action."
            ),
        }
    return packets


def score_all(projects, packets):
    """Every project gets a row; unflagged projects score 0."""
    rows = []
    for p in projects:
        pk = packets.get(p["project_id"])
        rows.append(pk or {
            "project_id": p["project_id"],
            "overall_risk_score": 0,
            "risk_band": "LOW",
            "district": p["district"],
            "gram_panchayat": p["gram_panchayat"],
            "work_category": p["work_category"],
            "work_description": p["work_description"],
            "sanctioned_amount": p["sanctioned_amount"],
            "released_amount": p["released_amount"],
            "status": p["status"],
            "ia_name": p["ia_name"],
            "ia_id": p["ia_id"],
            "mp_id": p["mp_id"],
            "latitude": p["latitude"],
            "longitude": p["longitude"],
            "sanction_date": p["sanction_date"],
            "fy": p["fy"],
            "amount_at_risk": 0,
            "anomalies": [],
            "disposition": "OPEN",
        })
    return rows


# ---------------------------------------------------------------------------
# Hash-chained ledger
# ---------------------------------------------------------------------------
class AuditLedger:
    """
    Append-only, hash-chained flag ledger.

    entry_hash = sha256(prev_hash + canonical_json(payload))

    verify() walks the chain and returns the first index where the recomputed
    hash disagrees - i.e. exactly where someone tampered. Demo this live: edit
    one byte of ledger.jsonl in front of the judges and run verify().
    """

    GENESIS = "0" * 64

    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _last_hash(self):
        if not self.path.exists():
            return self.GENESIS
        last = None
        with open(self.path, encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    last = json.loads(line)
        return last["entry_hash"] if last else self.GENESIS

    @staticmethod
    def _hash(prev, payload):
        blob = prev + json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(blob.encode()).hexdigest()

    def append(self, action, project_id, payload, actor="SYSTEM"):
        prev = self._last_hash()
        body = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "actor": actor,
            "action": action,
            "project_id": project_id,
            "payload": payload,
        }
        entry = {**body, "prev_hash": prev, "entry_hash": self._hash(prev, body)}
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
        return entry

    def verify(self):
        prev = self.GENESIS
        if not self.path.exists():
            return {"valid": True, "entries": 0}
        n = 0
        with open(self.path, encoding="utf-8") as f:
            for i, line in enumerate(f):
                if not line.strip():
                    continue
                e = json.loads(line)
                body = {k: e[k] for k in ("ts", "actor", "action", "project_id", "payload")}
                if e["prev_hash"] != prev or self._hash(prev, body) != e["entry_hash"]:
                    return {"valid": False, "broken_at_entry": i, "entries": n}
                prev = e["entry_hash"]
                n += 1
        return {"valid": True, "entries": n, "head": prev}
