"""
EVALUATION HARNESS  (owner: Member 1)

Almost no hackathon team can answer "how accurate is it?" with a number.
We can. This script measures the system against the planted ground truth and
produces three artefacts:

  1. Per-engine precision / recall / F1.
  2. An ABLATION: naive baseline vs our full pipeline, so we can prove that the
     normalisation layer and the peer-group statistics actually earn their keep
     rather than being decoration.
  3. A THRESHOLD SWEEP for the duplicate engine, which is the answer to
     "why 0.62 and not 0.8?" - we show the curve and point at the knee.

    python -m sentinel.evaluate
"""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path

from rapidfuzz import fuzz
from sklearn.feature_extraction.text import TfidfVectorizer

from . import config
from .engines import cost, duplicate, integrity, structuring
from .engines.duplicate import _candidate_pairs, haversine_m
from .normalize import semantic_core
from .schema import load_projects, load_ground_truth

ROOT = Path(__file__).resolve().parent.parent
DATA, OUT = ROOT / "data", ROOT / "out"

# MARCH_RUSH is an aggregate district-year signal: when a district-year is
# flagged, every work sanctioned inside the window is surfaced as context, so
# project-level precision is not the right measure for it. Scored separately.
AGGREGATE_TYPES = {"MARCH_RUSH"}


def prf(tp, fp, fn):
    p = tp / (tp + fp) if tp + fp else 0.0
    r = tp / (tp + fn) if tp + fn else 0.0
    f = 2 * p * r / (p + r) if p + r else 0.0
    return round(p, 3), round(r, 3), round(f, 3)


def score_by_type(findings, truth):
    pred = defaultdict(set)
    for f in findings:
        pred[f["type"]].add(f["project_id"])
    actual = defaultdict(set)
    for pid, types in truth.items():
        for t in types:
            actual[t].add(pid)

    rows = {}
    for t in sorted(set(pred) | set(actual)):
        tp = len(pred[t] & actual[t])
        fp = len(pred[t] - actual[t])
        fn = len(actual[t] - pred[t])
        p, r, f1 = prf(tp, fp, fn)
        rows[t] = {"tp": tp, "fp": fp, "fn": fn, "precision": p, "recall": r,
                   "f1": f1, "aggregate_signal": t in AGGREGATE_TYPES}
    return rows


def overall(findings, truth):
    """Did we catch the project at all, by any engine?"""
    pred = {f["project_id"] for f in findings if f["type"] not in AGGREGATE_TYPES}
    actual = {pid for pid, ts in truth.items() if not ts <= AGGREGATE_TYPES}
    tp = len(pred & actual)
    fp = len(pred - actual)
    fn = len(actual - pred)
    p, r, f1 = prf(tp, fp, fn)
    return {"tp": tp, "fp": fp, "fn": fn, "precision": p, "recall": r, "f1": f1}


# ---------------------------------------------------------------------------
# Ablation baselines - what a typical team would ship
# ---------------------------------------------------------------------------
def naive_duplicate(projects):
    """Baseline: raw description, no normalisation, TF-IDF word cosine only."""
    texts = [p["work_description"].lower() for p in projects]
    vec = TfidfVectorizer(analyzer="word", ngram_range=(1, 2), min_df=1)
    X = vec.fit_transform(texts)
    out = []
    for i, j in _candidate_pairs(projects):
        a, b = projects[i], projects[j]
        if a["work_category"] != b["work_category"]:
            continue
        d = haversine_m(a["latitude"], a["longitude"], b["latitude"], b["longitude"])
        if d > config.DUP_GEO_RADIUS_M:
            continue
        sim = float((X[i] @ X[j].T).toarray()[0][0])
        if sim < 0.82:              # the number the naive plan proposed
            continue
        later = a if a["sanction_date"] > b["sanction_date"] else b
        out.append({"project_id": later["project_id"], "type": "DUPLICATE_WORK",
                    "confidence": round(sim, 3), "severity": "MEDIUM",
                    "evidence": {}, "explanation": ""})
    return out


def naive_cost(projects):
    """Baseline: plain IsolationForest on amount, no SoR, no peer group."""
    try:
        import numpy as np
        from sklearn.ensemble import IsolationForest
    except ImportError:
        return []
    X = np.array([[p["sanctioned_amount"], p["physical_quantity"]] for p in projects], float)
    iso = IsolationForest(n_estimators=200, contamination=0.02, random_state=7).fit(X)
    lab = iso.predict(X)
    return [{"project_id": p["project_id"], "type": "COST_OVERRUN", "confidence": 0.6,
             "severity": "MEDIUM", "evidence": {}, "explanation": ""}
            for p, l in zip(projects, lab) if l == -1]


def threshold_sweep(projects, truth, lo=0.40, hi=0.90, step=0.02):
    """Precision/recall of the duplicate engine as the similarity floor moves."""
    actual = {pid for pid, ts in truth.items() if "DUPLICATE_WORK" in ts}
    cores = [semantic_core(p["work_description"]) for p in projects]
    vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=1)
    X = vec.fit_transform(cores)

    pairs = []
    for i, j in _candidate_pairs(projects):
        a, b = projects[i], projects[j]
        if a["work_category"] != b["work_category"]:
            continue
        d = haversine_m(a["latitude"], a["longitude"], b["latitude"], b["longitude"])
        if d > config.DUP_GEO_RADIUS_M:
            continue
        from datetime import date
        if abs((date.fromisoformat(a["sanction_date"]) -
                date.fromisoformat(b["sanction_date"])).days) < config.DUP_MIN_DAYS_APART:
            continue
        sem = float((X[i] @ X[j].T).toarray()[0][0])
        lex = fuzz.token_set_ratio(cores[i], cores[j]) / 100.0
        sim = 0.55 * sem + 0.45 * lex
        later = a if a["sanction_date"] > b["sanction_date"] else b
        pairs.append((sim, later["project_id"]))

    curve = []
    t = lo
    while t <= hi + 1e-9:
        pred = {pid for s, pid in pairs if s >= t}
        tp, fp, fn = len(pred & actual), len(pred - actual), len(actual - pred)
        p, r, f1 = prf(tp, fp, fn)
        curve.append({"threshold": round(t, 2), "precision": p, "recall": r,
                      "f1": f1, "flagged": len(pred)})
        t += step
    return curve


def main():
    projects = load_projects(DATA / "projects.csv")
    truth = load_ground_truth(DATA / "ground_truth.csv")

    full = (duplicate.run(projects) + cost.run(projects) + structuring.run(projects)
            + integrity.stalled(projects) + integrity.ghost_assets(projects)
            + integrity.compliance(projects) + integrity.march_rush(projects))

    baseline = (naive_duplicate(projects) + naive_cost(projects)
                + integrity.stalled(projects) + integrity.compliance(projects))

    per_type = score_by_type(full, truth)
    base_type = score_by_type(baseline, truth)
    curve = threshold_sweep(projects, truth)
    knee = max(curve, key=lambda c: c["f1"])

    report = {
        "corpus": {"projects": len(projects), "planted_frauds": len(truth)},
        "full_system": {"per_type": per_type, "overall": overall(full, truth)},
        "baseline_system": {
            "description": "raw-text TF-IDF duplicate matching at 0.82 + plain "
                           "IsolationForest on amount + same rule engines",
            "per_type": base_type,
            "overall": overall(baseline, truth),
        },
        "ablation_delta": {
            "duplicate_f1": round(per_type.get("DUPLICATE_WORK", {}).get("f1", 0)
                                  - base_type.get("DUPLICATE_WORK", {}).get("f1", 0), 3),
            "cost_f1": round(per_type.get("COST_OVERRUN", {}).get("f1", 0)
                             - base_type.get("COST_OVERRUN", {}).get("f1", 0), 3),
            "overall_f1": round(overall(full, truth)["f1"] - overall(baseline, truth)["f1"], 3),
        },
        "duplicate_threshold_sweep": curve,
        "chosen_threshold": config.DUP_TEXT_SIM_MIN,
        "best_f1_threshold": knee,
    }
    OUT.mkdir(exist_ok=True)
    (OUT / "evaluation.json").write_text(json.dumps(report, indent=2))

    print(f"{'ENGINE':<18}{'TP':>4}{'FP':>4}{'FN':>4}{'PREC':>8}{'REC':>8}{'F1':>8}")
    print("-" * 54)
    for t, r in per_type.items():
        tag = " *" if r["aggregate_signal"] else ""
        print(f"{t:<18}{r['tp']:>4}{r['fp']:>4}{r['fn']:>4}"
              f"{r['precision']:>8.3f}{r['recall']:>8.3f}{r['f1']:>8.3f}{tag}")
    o = report["full_system"]["overall"]
    b = report["baseline_system"]["overall"]
    print("-" * 54)
    print(f"{'OVERALL (full)':<18}{o['tp']:>4}{o['fp']:>4}{o['fn']:>4}"
          f"{o['precision']:>8.3f}{o['recall']:>8.3f}{o['f1']:>8.3f}")
    print(f"{'OVERALL (naive)':<18}{b['tp']:>4}{b['fp']:>4}{b['fn']:>4}"
          f"{b['precision']:>8.3f}{b['recall']:>8.3f}{b['f1']:>8.3f}")
    print(f"\n* aggregate district-year signal, project-level precision not meaningful")
    print(f"Best-F1 duplicate threshold: {knee['threshold']} (F1 {knee['f1']}), "
          f"shipping {config.DUP_TEXT_SIM_MIN}")
    return report


if __name__ == "__main__":
    main()
