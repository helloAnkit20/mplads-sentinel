"""
INTEGRITY ENGINES - stall, ghost asset, compliance, March rush.

Deliberately rule-based and transparent. Every one of these answers the
question "which guideline does this offend?" rather than "what does the model
think?". Owners: stall + march rush = Member 3, photo forensics + compliance
= Member 5.
"""
from __future__ import annotations

import hashlib
from collections import defaultdict
from datetime import date

from ..config import (
    INELIGIBLE_LAND,
    MARCH_RUSH_RATE_RATIO,
    MARCH_RUSH_SHARE_FLAG,
    MARCH_RUSH_WINDOW_DAYS,
    PREFERRED_IA_TYPES,
    STALL_NO_UPDATE_DAYS,
    STALL_OVERDUE_FACTOR,
)

TODAY = date(2026, 3, 31)   # evaluation "as on" date; pass in for production


# ---------------------------------------------------------------------------
# 1. STALLED WORK
# ---------------------------------------------------------------------------
def stalled(projects, today=TODAY):
    """
    A transparent two-condition rule. We deliberately did NOT ship an XGBoost
    delay classifier: the features available at sanction time (agency type,
    season, allocation) carry weak signal, and no District Magistrate can act
    on 'the gradient boosted model assigned 0.71'. A rule an officer can
    restate in one sentence gets acted on; a model score gets ignored.
    """
    out = []
    for p in projects:
        if p["status"] not in ("SANCTIONED", "IN_PROGRESS"):
            continue
        last = date.fromisoformat(p["last_update_date"])
        silent = (today - last).days
        sanc = date.fromisoformat(p["sanction_date"])
        elapsed = (today - sanc).days
        planned = p["planned_duration_days"] or 180
        overdue_ratio = elapsed / planned

        c1 = silent >= STALL_NO_UPDATE_DAYS
        c2 = overdue_ratio >= STALL_OVERDUE_FACTOR
        if not (c1 and c2):
            continue
        conf = min(0.95, 0.45 + 0.001 * (silent - STALL_NO_UPDATE_DAYS)
                   + 0.18 * min(2.0, overdue_ratio - STALL_OVERDUE_FACTOR))
        out.append({
            "project_id": p["project_id"],
            "type": "STALLED_WORK",
            "confidence": round(max(0.5, conf), 3),
            "severity": "HIGH" if overdue_ratio > 2.5 else "MEDIUM",
            "evidence": {
                "days_since_last_update": silent,
                "days_since_sanction": elapsed,
                "planned_duration_days": planned,
                "overdue_ratio": round(overdue_ratio, 2),
                "funds_released_inr": p["released_amount"],
                "funds_blocked_inr": p["sanctioned_amount"] - p["released_amount"],
                "status": p["status"],
            },
            "explanation": (
                f"No progress update for {silent} days. Elapsed time is "
                f"{overdue_ratio:.1f}x the planned duration of {planned} days, and "
                f"Rs {p['released_amount']:,} has already been released against an "
                f"incomplete asset."
            ),
        })
    return out


# ---------------------------------------------------------------------------
# 2. GHOST ASSET - completion-photograph forensics
# ---------------------------------------------------------------------------
def perceptual_hash(image_path: str, hash_size: int = 8) -> str:
    """
    Real pHash (dHash variant) for the live upload path.

    Why perceptual and not cryptographic: a contractor re-uploading the same
    site photo will usually recompress or lightly crop it, which changes an MD5
    completely but barely moves a perceptual hash. Comparing by Hamming distance
    therefore still catches the reuse.

    NOTE: this is the function wired to the Field Verification upload form.
    The synthetic corpus stores pre-computed hashes so the batch pipeline runs
    without any image files.
    """
    from PIL import Image
    img = Image.open(image_path).convert("L").resize((hash_size + 1, hash_size))
    px = list(img.getdata())
    bits = []
    for row in range(hash_size):
        for col in range(hash_size):
            left = px[row * (hash_size + 1) + col]
            right = px[row * (hash_size + 1) + col + 1]
            bits.append("1" if left > right else "0")
    return f"{int(''.join(bits), 2):0{hash_size * hash_size // 4}x}"


def hamming(a: str, b: str) -> int:
    if len(a) != len(b):
        return 999
    return bin(int(a, 16) ^ int(b, 16)).count("1")


def ghost_assets(projects, max_hamming=0):
    """
    Flag projects marked COMPLETED whose completion photograph has already been
    used on a different project. max_hamming=0 is exact reuse; raise to 6-8 when
    running against real re-compressed images.
    """
    by_hash = defaultdict(list)
    for p in projects:
        h = p.get("completion_photo_hash")
        if h:
            by_hash[h].append(p)

    out = []
    for h, group in by_hash.items():
        if len(group) < 2:
            continue
        group = sorted(group, key=lambda x: x["completion_date"] or x["sanction_date"])
        first = group[0]
        for p in group[1:]:
            out.append({
                "project_id": p["project_id"],
                "type": "GHOST_ASSET",
                "confidence": 0.94,
                "severity": "HIGH",
                "evidence": {
                    "photo_hash": h,
                    "reused_from_project": first["project_id"],
                    "reused_from_district": first["district"],
                    "hamming_distance": 0,
                    "amount_released_inr": p["released_amount"],
                    "distance_km": round(_km(p, first), 2),
                },
                "explanation": (
                    f"The completion photograph submitted as proof of work is byte-identical "
                    f"to the photograph already submitted for {first['project_id']} "
                    f"({first['district']}, {_km(p, first):.1f} km away). Payment of "
                    f"Rs {p['released_amount']:,} was released against this proof."
                ),
            })
    return out


def _km(a, b):
    from .duplicate import haversine_m
    return haversine_m(a["latitude"], a["longitude"], b["latitude"], b["longitude"]) / 1000.0


# ---------------------------------------------------------------------------
# 3. GUIDELINE COMPLIANCE
# ---------------------------------------------------------------------------
def compliance(projects):
    """
    Deterministic guideline checks. Zero false positives by construction - the
    record either says the land is private or it does not. These are the flags a
    District Magistrate can action the same afternoon.
    """
    out = []
    for p in projects:
        breaches = []
        if str(p["land_tenure"]).upper() in INELIGIBLE_LAND:
            breaches.append(f"asset created on {p['land_tenure'].lower()} land")
        if p["recommendation_date"] and p["sanction_date"]:
            if date.fromisoformat(p["sanction_date"]) < date.fromisoformat(p["recommendation_date"]):
                breaches.append("sanctioned before the MP's recommendation was recorded")
        if not p["recommendation_date"]:
            breaches.append("no MP recommendation on record")
        if not breaches:
            continue
        out.append({
            "project_id": p["project_id"],
            "type": "INELIGIBLE_WORK",
            "confidence": 0.99,
            "severity": "HIGH",
            "evidence": {
                "breaches": breaches,
                "land_tenure": p["land_tenure"],
                "ia_type": p["ia_type"],
                "ia_preferred": p["ia_type"] in PREFERRED_IA_TYPES,
                "amount_at_risk": p["sanctioned_amount"],
            },
            "explanation": "Guideline breach: " + "; ".join(breaches) + ".",
        })
    return out


# ---------------------------------------------------------------------------
# 4. MARCH RUSH (aggregate signal, attributed down to projects)
# ---------------------------------------------------------------------------
def march_rush(projects):
    by_fy_district = defaultdict(list)
    for p in projects:
        by_fy_district[(p["fy"], p["district"])].append(p)

    out = []
    for (fy, district), items in by_fy_district.items():
        total = sum(p["sanctioned_amount"] for p in items)
        if total <= 0:
            continue
        rush = []
        for p in items:
            sd = date.fromisoformat(p["sanction_date"])
            if sd.month == 3 and sd.day >= (32 - MARCH_RUSH_WINDOW_DAYS):
                rush.append(p)
        rush_value = sum(p["sanctioned_amount"] for p in rush)
        share = rush_value / total
        # Rate comparison is the defensible test: a district that sanctions
        # evenly would commit roughly (window_days / 365) of its value in the
        # window. We compare rupees-per-day inside the window against
        # rupees-per-day across the rest of the year.
        rest_value = total - rush_value
        rest_days = max(1, 365 - MARCH_RUSH_WINDOW_DAYS)
        rate_in = rush_value / MARCH_RUSH_WINDOW_DAYS
        rate_out = rest_value / rest_days
        rate_ratio = rate_in / rate_out if rate_out > 0 else float("inf")
        if len(rush) < 3 or (share < MARCH_RUSH_SHARE_FLAG and rate_ratio < MARCH_RUSH_RATE_RATIO):
            continue
        for p in rush:
            out.append({
                "project_id": p["project_id"],
                "type": "MARCH_RUSH",
                "confidence": round(min(0.85, 0.35 + share + 0.03 * min(6, rate_ratio)), 3),
                "severity": "LOW" if share < 0.45 else "MEDIUM",
                "evidence": {
                    "fy": fy,
                    "district": district,
                    "district_fy_total_inr": int(total),
                    "last_window_value_inr": int(rush_value),
                    "share_of_annual": round(share, 3),
                "rate_ratio_vs_rest_of_year": round(rate_ratio, 2),
                    "works_in_window": len(rush),
                    "window_days": MARCH_RUSH_WINDOW_DAYS,
                },
                "explanation": (
                    f"{share*100:.0f}% of {district}'s entire {fy} sanction value "
                    f"(Rs {rush_value:,.0f} across {len(rush)} works) was committed in the "
                    f"final {MARCH_RUSH_WINDOW_DAYS} days of the financial year - a sanction "
                    f"rate {rate_ratio:.1f}x the rest-of-year daily rate, compressing "
                    f"technical appraisal and quality checks."
                ),
            })
    return out
