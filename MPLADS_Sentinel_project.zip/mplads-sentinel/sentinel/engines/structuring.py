"""
STRUCTURING & COLLUSION GRAPH ENGINE  (owner: Member 2)

This is the differentiator almost nobody else will build.

Part A - SPLIT TENDER DETECTION
  A work above the sanction/tender threshold needs a higher approval authority
  and an open tender. The standard evasion is to break one Rs 22 lakh job into
  five Rs 4.7 lakh jobs, all to the same agency, in the same Gram Panchayat, in
  the same fortnight. No single record looks wrong. Only the CLUSTER looks wrong.

  Rule (fully explainable, no ML):
      group by (implementing agency, gram panchayat, rolling 14-day window)
      count works whose value is between 85% and 100% of the threshold
      flag the cluster if that count >= 3 and the cluster total exceeds the
      threshold that was being avoided.

Part B - AGENCY CONCENTRATION (collusion ring signal)
  Build a bipartite graph:  Implementing Agency  <->  Gram Panchayat
  For each GP compute the Herfindahl-Hirschman Index of agency share of value.
  A GP where one agency holds >70% of all sanctioned value over multiple years
  is the classic signature of a captured local market. We surface it as a
  CONTEXT signal on the dashboard - it raises the priority of other flags
  against the same agency, and the network picture is what makes a judge lean
  forward.

We use networkx because the same graph object gives us degree, components and
centrality for free, and because it lets us export the subgraph straight into
the audit dossier as evidence.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import date, timedelta

import networkx as nx

from ..config import (
    SANCTION_SPLIT_THRESHOLD,
    SPLIT_MIN_WORKS,
    SPLIT_PROXIMITY_BAND,
    SPLIT_WINDOW_DAYS,
)


def _d(s):
    return date.fromisoformat(s)


def detect_splits(projects):
    """Sliding-window cluster detection over (IA, GP)."""
    buckets = defaultdict(list)
    for p in projects:
        buckets[(p["ia_id"], p["gram_panchayat"])].append(p)

    findings = []
    lo = SANCTION_SPLIT_THRESHOLD * SPLIT_PROXIMITY_BAND
    hi = SANCTION_SPLIT_THRESHOLD

    for (ia_id, gp), items in buckets.items():
        near = sorted([p for p in items if lo <= p["sanctioned_amount"] <= hi],
                      key=lambda x: x["sanction_date"])
        if len(near) < SPLIT_MIN_WORKS:
            continue
        i = 0
        while i < len(near):
            start = _d(near[i]["sanction_date"])
            window = [p for p in near[i:]
                      if _d(p["sanction_date"]) <= start + timedelta(days=SPLIT_WINDOW_DAYS)]
            if len(window) >= SPLIT_MIN_WORKS:
                total = sum(p["sanctioned_amount"] for p in window)
                cluster_ids = [p["project_id"] for p in window]
                conf = min(0.96, 0.55 + 0.09 * (len(window) - SPLIT_MIN_WORKS)
                           + 0.10 * min(1.0, total / (3 * SANCTION_SPLIT_THRESHOLD)))
                for p in window:
                    findings.append({
                        "project_id": p["project_id"],
                        "type": "SPLIT_TENDER",
                        "confidence": round(conf, 3),
                        "severity": "HIGH" if len(window) >= 4 else "MEDIUM",
                        "evidence": {
                            "cluster_size": len(window),
                            "cluster_project_ids": cluster_ids,
                            "cluster_total_inr": total,
                            "threshold_inr": SANCTION_SPLIT_THRESHOLD,
                            "window_days": SPLIT_WINDOW_DAYS,
                            "implementing_agency": p["ia_name"],
                            "ia_id": ia_id,
                            "gram_panchayat": gp,
                            "window_start": near[i]["sanction_date"],
                            "individual_amounts": [x["sanctioned_amount"] for x in window],
                        },
                        "explanation": (
                            f"{len(window)} works totalling Rs {total:,.0f} were sanctioned to "
                            f"{p['ia_name']} in {gp} within {SPLIT_WINDOW_DAYS} days, each valued "
                            f"between {int(SPLIT_PROXIMITY_BAND*100)}% and 100% of the "
                            f"Rs {SANCTION_SPLIT_THRESHOLD:,} sanction threshold. Pattern is "
                            f"consistent with splitting one work to stay below the threshold."
                        ),
                    })
                i += len(window)
            else:
                i += 1
    # de-duplicate: keep highest confidence per project
    best = {}
    for f in findings:
        k = f["project_id"]
        if k not in best or f["confidence"] > best[k]["confidence"]:
            best[k] = f
    return list(best.values())


def build_agency_graph(projects):
    """Bipartite IA <-> GP graph, weighted by sanctioned value."""
    G = nx.Graph()
    for p in projects:
        ia = f"IA::{p['ia_id']}"
        gp = f"GP::{p['district']}::{p['gram_panchayat']}"
        G.add_node(ia, kind="agency", label=p["ia_name"], ia_type=p["ia_type"])
        G.add_node(gp, kind="gp", label=p["gram_panchayat"], district=p["district"])
        if G.has_edge(ia, gp):
            G[ia][gp]["value"] += p["sanctioned_amount"]
            G[ia][gp]["works"] += 1
        else:
            G.add_edge(ia, gp, value=p["sanctioned_amount"], works=1)
    return G


def concentration_report(projects, min_value=2_000_000):
    """
    Herfindahl-Hirschman Index of agency share per Gram Panchayat.
    HHI = sum of squared market shares. 1.0 = a single agency holds everything.
    """
    G = build_agency_graph(projects)
    out = []
    for node, data in G.nodes(data=True):
        if data.get("kind") != "gp":
            continue
        edges = [(n, G[node][n]) for n in G.neighbors(node)]
        total = sum(e["value"] for _, e in edges)
        if total < min_value or not edges:
            continue
        shares = [(n, e["value"] / total, e["works"]) for n, e in edges]
        hhi = sum(s * s for _, s, _ in shares)
        top = max(shares, key=lambda x: x[1])
        out.append({
            "gram_panchayat": data["label"],
            "district": data["district"],
            "total_value_inr": int(total),
            "num_agencies": len(edges),
            "hhi": round(hhi, 3),
            "dominant_agency": G.nodes[top[0]]["label"],
            "dominant_agency_id": top[0].replace("IA::", ""),
            "dominant_share": round(top[1], 3),
            "dominant_works": top[2],
            "concentration_band": (
                "CAPTURED" if hhi >= 0.6 else "CONCENTRATED" if hhi >= 0.35 else "COMPETITIVE"
            ),
        })
    return sorted(out, key=lambda x: -x["hhi"])


def run(projects):
    return detect_splits(projects)
