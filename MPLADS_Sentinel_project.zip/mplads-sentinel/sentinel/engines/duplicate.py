"""
DUPLICATE WORK ENGINE  (owner: Member 1)

Detects the same physical asset being sanctioned twice under a rephrased name.

Method - a three-signal AND, not a single model:
  1. SPATIAL   haversine distance < DUP_GEO_RADIUS_M (equivalent to the
               PostGIS predicate  ST_DWithin(a.geom::geography, b.geom::geography, 150)
               which is what runs in production; we implement it in numpy here so
               the whole pipeline runs with zero infrastructure on a laptop).
  2. TEXTUAL   blended similarity on the *normalised semantic core*:
                 0.55 * TF-IDF char(3,5) cosine   (robust to spelling drift)
               + 0.45 * rapidfuzz token_set_ratio (robust to word reordering)
  3. CATEGORY  same work_category, and sanctions at least 30 days apart
               (phased works and genuine adjacent stretches are excluded).

Why not just a sentence-transformer?
  We evaluated both. On this corpus the normalised lexical blend beats a raw
  MiniLM embedding because MiniLM is English-trained and these descriptions are
  transliterated Bengali/Hindi boilerplate - see docs and evaluate.py --ablation.
  The production path is a multilingual encoder (LaBSE / multilingual-e5) applied
  to the SAME normalised core; the interface below is model-agnostic, so swapping
  in embeddings is a one-line change (pass `embedder=`).

Complexity: naive all-pairs on 2.5k rows is 3.1M comparisons. We block by a
~1.1 km geo-grid cell first, which drops it to a few thousand candidate pairs
and keeps the engine linear in practice. This is the same blocking idea used in
record-linkage systems and it is why the API answers in milliseconds.
"""
from __future__ import annotations

import math
from collections import defaultdict

import numpy as np
from rapidfuzz import fuzz
from sklearn.feature_extraction.text import TfidfVectorizer

from ..config import (
    DUP_GEO_RADIUS_M,
    DUP_HARD_FLAG_SIM,
    DUP_MIN_DAYS_APART,
    DUP_TEXT_SIM_MIN,
)
from ..normalize import semantic_core, structured_keys

EARTH_R = 6_371_000.0
GRID_DEG = 0.01  # ~1.1 km blocking cell


def haversine_m(lat1, lon1, lat2, lon2) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = p2 - p1
    dl = math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * EARTH_R * math.asin(math.sqrt(a))


def _cell(lat, lon):
    return (int(lat / GRID_DEG), int(lon / GRID_DEG))


def _candidate_pairs(projects):
    """Block on a geo grid; compare a cell against itself and its 8 neighbours."""
    buckets = defaultdict(list)
    for i, p in enumerate(projects):
        buckets[_cell(p["latitude"], p["longitude"])].append(i)
    seen = set()
    for (cx, cy), idxs in buckets.items():
        neigh = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                neigh.extend(buckets.get((cx + dx, cy + dy), []))
        for i in idxs:
            for j in neigh:
                if i >= j:
                    continue
                key = (i, j)
                if key in seen:
                    continue
                seen.add(key)
                yield i, j


def run(projects, embedder=None):
    """
    projects: list of dicts (see schema.py)
    embedder: optional callable(list[str]) -> np.ndarray of unit vectors.
              If supplied, its cosine replaces the TF-IDF component.
    returns:  list of finding dicts
    """
    cores = [semantic_core(p["work_description"]) for p in projects]
    keys = [structured_keys(p["work_description"]) for p in projects]

    if embedder is not None:
        emb = embedder(cores)
        emb = emb / (np.linalg.norm(emb, axis=1, keepdims=True) + 1e-9)
        tfidf = None
    else:
        vec = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=1)
        tfidf = vec.fit_transform(cores)
        emb = None

    findings = []
    for i, j in _candidate_pairs(projects):
        a, b = projects[i], projects[j]
        if a["work_category"] != b["work_category"]:
            continue
        dist = haversine_m(a["latitude"], a["longitude"], b["latitude"], b["longitude"])
        if dist > DUP_GEO_RADIUS_M:
            continue
        days = abs((_d(a["sanction_date"]) - _d(b["sanction_date"])).days)
        if days < DUP_MIN_DAYS_APART:
            continue

        if emb is not None:
            sem = float(emb[i] @ emb[j])
        else:
            sem = float((tfidf[i] @ tfidf[j].T).toarray()[0][0])
        lex = fuzz.token_set_ratio(cores[i], cores[j]) / 100.0
        sim = 0.55 * sem + 0.45 * lex
        if sim < DUP_TEXT_SIM_MIN:
            continue

        # ward mismatch is exculpatory evidence: two different wards is a
        # legitimate reason for two nearby works with similar names
        same_ward = keys[i]["ward"] == keys[j]["ward"]
        conf = min(0.99, sim * (1.0 if same_ward else 0.82) *
                   (1.0 if dist < 80 else 0.9))
        severity = "HIGH" if (sim >= DUP_HARD_FLAG_SIM and dist <= 100) else "MEDIUM"

        # the later sanction is the one that gets flagged - you cannot fault a
        # project for a duplicate that had not happened yet
        later, earlier = (a, b) if _d(a["sanction_date"]) > _d(b["sanction_date"]) else (b, a)
        findings.append({
            "project_id": later["project_id"],
            "type": "DUPLICATE_WORK",
            "confidence": round(conf, 3),
            "severity": severity,
            "evidence": {
                "matched_project_id": earlier["project_id"],
                "distance_m": round(dist, 1),
                "text_similarity": round(sim, 3),
                "semantic_component": round(sem, 3),
                "lexical_component": round(lex, 3),
                "same_ward": same_ward,
                "days_apart": days,
                "this_description": later["work_description"],
                "matched_description": earlier["work_description"],
                "normalised_core_a": semantic_core(later["work_description"]),
                "normalised_core_b": semantic_core(earlier["work_description"]),
                "amount_at_risk": later["sanctioned_amount"],
            },
            "explanation": (
                f"Sanctioned {days} days after {earlier['project_id']}, "
                f"{dist:.0f} m away, same work category, normalised description "
                f"similarity {sim:.2f}. The earlier work was already "
                f"{earlier['status'].lower()}."
            ),
        })
    return findings


def _d(s):
    from datetime import date
    return date.fromisoformat(s)
