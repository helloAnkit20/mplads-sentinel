"""
COST FORENSICS ENGINE  (owner: Member 5)

Two independent, explainable signals - deliberately NOT a black-box anomaly
detector as the primary evidence.

  SIGNAL A - SoR ratio.
      unit_rate = sanctioned_amount / physical_quantity
      benchmark = State Schedule of Rates for that category
                  x district cost index for that district
      ratio     = unit_rate / benchmark
    This is exactly how a PWD auditor or a CAG audit party works: they do not
    ask "is this invoice statistically odd", they ask "what does the Schedule
    of Rates say a kilometre of CC road costs in this district this year".
    An officer can act on "you paid 2.4x the district SoR". No officer can act
    on "the isolation forest gave it -0.31".

  SIGNAL B - robust peer-group z-score.
      Peer group = (work_category, district). We use the MEDIAN and the MAD
      (median absolute deviation), not mean and standard deviation, because a
      handful of inflated projects would drag a mean upward and hide themselves.
      modified z = 0.6745 * (x - median) / MAD
    This catches inflation even where our SoR table is stale or missing, and it
    is still fully explainable: "this project's unit rate sits N robust standard
    deviations above the median of 143 comparable works in the same district".

  IsolationForest is retained ONLY as a corroborating tertiary score in the
  multivariate case (see `isolation_support`). It never raises a flag on its
  own. Say this to the judges - it is the difference between a demo and an
  auditable system.
"""
from __future__ import annotations

from collections import defaultdict
from statistics import median

from ..config import (
    COST_ROBUST_Z_FLAG,
    COST_SOR_RATIO_FLAG,
    COST_SOR_RATIO_WARN,
    DISTRICT_COST_INDEX,
    SOR_RATES,
)


def _mad(values, med):
    return median([abs(v - med) for v in values]) or 1e-9


def build_peer_stats(projects):
    groups = defaultdict(list)
    for p in projects:
        if p["physical_quantity"]:
            rate = p["sanctioned_amount"] / p["physical_quantity"]
            groups[(p["work_category"], p["district"])].append(rate)
    stats = {}
    for k, vals in groups.items():
        if len(vals) < 8:          # too few peers to make a claim
            continue
        med = median(vals)
        stats[k] = {"median": med, "mad": _mad(vals, med), "n": len(vals)}
    return stats


def isolation_support(projects):
    """
    Optional multivariate corroboration. Returns {project_id: score in [0,1]}.
    Used only to raise confidence on an already-flagged project, never to flag.
    """
    try:
        import numpy as np
        from sklearn.ensemble import IsolationForest
    except ImportError:
        return {}
    rows, ids = [], []
    for p in projects:
        if not p["physical_quantity"]:
            continue
        bench = SOR_RATES[p["work_category"]]["rate"] * DISTRICT_COST_INDEX[p["district"]]
        rows.append([
            (p["sanctioned_amount"] / p["physical_quantity"]) / bench,
            np.log1p(p["sanctioned_amount"]),
            np.log1p(p["physical_quantity"]),
            p["planned_duration_days"],
        ])
        ids.append(p["project_id"])
    if len(rows) < 50:
        return {}
    X = np.array(rows, dtype=float)
    iso = IsolationForest(n_estimators=200, contamination=0.03, random_state=7).fit(X)
    raw = -iso.score_samples(X)
    lo, hi = raw.min(), raw.max()
    norm = (raw - lo) / (hi - lo + 1e-9)
    return dict(zip(ids, norm.round(3).tolist()))


def run(projects):
    stats = build_peer_stats(projects)
    iso = isolation_support(projects)
    findings = []

    for p in projects:
        qty = p["physical_quantity"]
        if not qty:
            continue
        unit_rate = p["sanctioned_amount"] / qty
        cat = p["work_category"]
        bench = SOR_RATES[cat]["rate"] * DISTRICT_COST_INDEX[p["district"]]
        ratio = unit_rate / bench

        st = stats.get((cat, p["district"]))
        zmod = None
        if st:
            zmod = 0.6745 * (unit_rate - st["median"]) / st["mad"]

        hit_sor = ratio >= COST_SOR_RATIO_FLAG
        hit_z = zmod is not None and zmod >= COST_ROBUST_Z_FLAG
        warn = ratio >= COST_SOR_RATIO_WARN

        if not (hit_sor or hit_z):
            continue

        conf = 0.0
        if hit_sor:
            conf = max(conf, min(0.95, 0.55 + 0.22 * (ratio - COST_SOR_RATIO_FLAG)))
        if hit_z:
            conf = max(conf, min(0.92, 0.5 + 0.05 * (zmod - COST_ROBUST_Z_FLAG)))
        if hit_sor and hit_z:
            conf = min(0.97, conf + 0.12)
        # tertiary corroboration only
        conf = min(0.98, conf + 0.05 * iso.get(p["project_id"], 0.0))

        excess = int(p["sanctioned_amount"] - (bench * qty))
        findings.append({
            "project_id": p["project_id"],
            "type": "COST_OVERRUN",
            "confidence": round(conf, 3),
            "severity": "HIGH" if (hit_sor and hit_z) else "MEDIUM",
            "evidence": {
                "unit_rate": round(unit_rate, 2),
                "unit": SOR_RATES[cat]["unit"],
                "district_sor_benchmark": round(bench, 2),
                "sor_ratio": round(ratio, 3),
                "peer_median_rate": round(st["median"], 2) if st else None,
                "peer_group_size": st["n"] if st else None,
                "robust_z": round(zmod, 2) if zmod is not None else None,
                "isolation_support": iso.get(p["project_id"]),
                "estimated_excess_inr": excess,
                "warn_band_only": warn and not hit_sor,
            },
            "explanation": (
                f"Unit rate Rs {unit_rate:,.0f} per {SOR_RATES[cat]['unit']} is "
                f"{ratio:.2f}x the {p['district']} Schedule of Rates benchmark "
                f"(Rs {bench:,.0f})" +
                (f", and {zmod:.1f} robust standard deviations above the median of "
                 f"{st['n']} comparable works in the same district" if st else "") +
                f". Estimated excess over benchmark: Rs {excess:,.0f}."
            ),
        })
    return findings
