"""
Description normalisation for Indian government work records.

WHY THIS FILE EXISTS (this is a Q&A answer, memorise it):
An off-the-shelf English sentence encoder scores
  "Construction of C.C. Road at Ramnagar G.P. Ward No 7"
against
  "Nirman of Concrete Rasta near Ramnagar Gram Panchyat Ward-7"
poorly, because ~60% of every MPLADS description is boilerplate
("Construction of ... at ... Gram Panchayat") and the discriminative part is
a transliterated place name plus a ward number. The embedding is dominated by
the boilerplate, so *every* road project looks similar to every other road
project and the model cannot separate a true duplicate from a normal pair.

So we do three things before any similarity is computed:
  1. Fold transliteration variants to a canonical token (nirman -> construction,
     rasta/sarak -> road, vidyalaya -> school, peyojal -> water ...).
  2. Strip administrative boilerplate that carries no discriminating signal.
  3. Extract structured keys (ward number, phase, quantity) separately so they
     are compared as fields, not as text.

The result is a short "semantic core" string. Similarity is then computed on
the core, where the signal-to-noise ratio is far higher.
"""
from __future__ import annotations

import re
import unicodedata

# Transliteration / synonym folding. Extend this table with the regional
# vocabulary of whichever state you demo on - it is the cheapest accuracy win
# in the whole system.
SYNONYMS = {
    r"\bnirman(?:\s+karya)?\b": "construction",
    r"\bnirmaan\b": "construction",
    r"\bconstn?\b": "construction",
    r"\brasta\b": "road", r"\bsarak\b": "road", r"\bsadak\b": "road",
    r"\bc\.?\s?c\.?\s+(?:road|rd)\b": "cc road",
    r"\bconcrete\s+road\b": "cc road",
    r"\brcc\s+road\b": "cc road",
    r"\bvidyalaya\b": "school", r"\bpathshala\b": "school",
    r"\bpry\b": "primary", r"\bf\.?\s?p\.?\s+school\b": "primary school",
    r"\bsamudayik\s+bhavan\b": "community hall",
    r"\bcommunity\s+cent(?:re|er)\b": "community hall",
    r"\bnala\b": "drain", r"\bnaala\b": "drain",
    r"\bpeyojal\b": "water", r"\bpeyjal\b": "water",
    r"\bshauchalay\b": "toilet",
    r"\bcompound\s+wall\b": "boundary wall",
    r"\bmore\b": "crossing", r"\bmod\b": "crossing",
    r"\bpukur\b": "pond", r"\bmandir\b": "temple",
    r"\bg\.?\s?p\.?\b": "gp", r"\bgram\s+panch(?:a|y)?ath?\b": "gp",
    r"\bgram\s+panchyat\b": "gp",
    r"\bsupply\s*(?:&|and)\s*fixing\b": "installation",
    r"\binstallation\b": "installation",
    r"\bnos?\b": "",
    r"\boverhead\s+reservoir\b": "water tank",
}

# Tokens that appear in almost every record and therefore discriminate nothing.
BOILERPLATE = {
    "construction", "of", "at", "near", "the", "a", "an", "and", "for", "in",
    "to", "from", "upto", "under", "with", "by", "gp", "ward", "no", "nos",
    "improvement", "work", "works", "sanctioned", "additional", "installation",
    "starting", "block", "district", "village", "dist", "vill",
}

WARD_RE = re.compile(r"ward\s*(?:no\.?|-|#)?\s*(\d{1,3})", re.I)
PHASE_RE = re.compile(r"phase\s*[-\s]*([ivx\d]+)", re.I)
NUM_RE = re.compile(r"\b\d+(?:\.\d+)?\b")


def _ascii_fold(s: str) -> str:
    s = unicodedata.normalize("NFKD", s)
    return "".join(c for c in s if not unicodedata.combining(c))


def structured_keys(desc: str) -> dict:
    """Pull out fields that must be compared as fields, not as free text."""
    ward = WARD_RE.search(desc)
    phase = PHASE_RE.search(desc)
    return {
        "ward": int(ward.group(1)) if ward else None,
        "phase": phase.group(1).lower() if phase else None,
    }


def semantic_core(desc: str) -> str:
    """
    Reduce a raw description to its discriminating core.

    >>> semantic_core("Construction of C.C. Road from Bazar More to Post Office at Ramnagar G.P. Ward No 7")
    'bazar crossing cc post office ramnagar road'
    """
    s = _ascii_fold(desc.lower())
    s = re.sub(r"[^\w\s.&-]", " ", s)
    for pat, rep in SYNONYMS.items():
        s = re.sub(pat, rep, s)
    s = re.sub(r"[.\-&]", " ", s)
    s = WARD_RE.sub(" ", s)
    s = PHASE_RE.sub(" ", s)
    s = NUM_RE.sub(" ", s)
    toks = [t for t in s.split() if t and t not in BOILERPLATE and len(t) > 1]
    # order-independent core so "A to B" and "B to A" collapse together
    return " ".join(sorted(set(toks)))


if __name__ == "__main__":
    samples = [
        "Construction of C.C. Road from Bazar More to Post Office at Ramnagar G.P. Ward No 7",
        "Nirman of concrete road at Ramnagar, Ward-7 (from Post Office upto Bazar More) (Phase-II)",
        "Construction of boundary wall of Simulia School at Debipur",
        "Simulia Vidyalaya compound wall nirman at Debipur Gram Panchyat",
    ]
    for s in samples:
        print(f"{s}\n   -> {semantic_core(s)}  {structured_keys(s)}\n")
