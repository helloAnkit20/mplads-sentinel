"""
Canonical project record + loader.

This shape is intentionally a superset of what MPLADS-eSAKSHI already holds
(MP recommendation, District Authority sanction, Implementing Agency, vendor
payment stages, completion photograph). Nothing here asks a department to
collect data it does not already collect - which is the single most important
thing to be able to say to a government judge.

Fields we consume that eSAKSHI holds today:
    project_id, mp_id, district, gram_panchayat, work_description,
    sanctioned_amount, released_amount, sanction_date, status,
    completion photograph
Fields we require that must come from the DPR / sanction order:
    physical_quantity + unit  (needed for unit-rate benchmarking)
    latitude, longitude       (already captured by the eSAKSHI mobile app on
                               photo upload)
"""
from __future__ import annotations

import csv
from pathlib import Path

REQUIRED = [
    "project_id", "district", "gram_panchayat", "work_category",
    "work_description", "sanctioned_amount", "latitude", "longitude",
    "ia_id", "sanction_date", "status",
]

INT_FIELDS = ["sanctioned_amount", "released_amount", "ward_no", "planned_duration_days"]
FLOAT_FIELDS = ["latitude", "longitude", "physical_quantity"]
BOOL_FIELDS = ["sc_area", "st_area"]


def _coerce(row):
    for f in INT_FIELDS:
        row[f] = int(float(row.get(f) or 0))
    for f in FLOAT_FIELDS:
        row[f] = float(row.get(f) or 0)
    for f in BOOL_FIELDS:
        row[f] = str(row.get(f, "")).strip().lower() in ("true", "1", "yes")
    return row


def load_projects(path: str | Path):
    path = Path(path)
    with open(path, newline="", encoding="utf-8") as f:
        rows = [_coerce(r) for r in csv.DictReader(f)]
    missing = [c for c in REQUIRED if rows and c not in rows[0]]
    if missing:
        raise ValueError(f"Input is missing required columns: {missing}")
    return rows


def load_ground_truth(path: str | Path):
    path = Path(path)
    truth = {}
    with open(path, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            truth.setdefault(r["project_id"], set()).add(r["fraud_type"])
    return truth
