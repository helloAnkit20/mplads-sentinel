"""
Minimal markdown -> PDF renderer for the team briefs.
Supports: # ## ###, - bullets, 1. numbered, > callout, `code`, **bold**, *italic*,
--- rule, | tables |, and ```blocks```.
"""
from __future__ import annotations

import html
import re
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    HRFlowable, KeepTogether, ListFlowable, ListItem, PageBreak, Paragraph,
    SimpleDocTemplate, Spacer, Table, TableStyle,
)

INK = colors.HexColor("#12212F")
INK2 = colors.HexColor("#22394E")
RED = colors.HexColor("#A32A1E")
MUTED = colors.HexColor("#6C7683")
RULE = colors.HexColor("#CFC8BA")
PAPER = colors.HexColor("#F5F2EB")
CODEBG = colors.HexColor("#EEEBE3")


def styles():
    ss = getSampleStyleSheet()
    return {
        "h1": ParagraphStyle("h1", parent=ss["Heading1"], fontSize=17, leading=20,
                             textColor=INK, spaceBefore=2, spaceAfter=7),
        "h2": ParagraphStyle("h2", parent=ss["Heading2"], fontSize=12.5, leading=15,
                             textColor=INK, spaceBefore=13, spaceAfter=5),
        "h3": ParagraphStyle("h3", parent=ss["Heading3"], fontSize=10.5, leading=13,
                             textColor=INK2, spaceBefore=9, spaceAfter=3),
        "p": ParagraphStyle("p", parent=ss["Normal"], fontSize=9.3, leading=13.4,
                            alignment=TA_JUSTIFY, spaceAfter=5),
        "li": ParagraphStyle("li", parent=ss["Normal"], fontSize=9.3, leading=13.2,
                             spaceAfter=2.5),
        "quote": ParagraphStyle("q", parent=ss["Normal"], fontSize=9.2, leading=13,
                                textColor=INK2, leftIndent=8, spaceAfter=5),
        "code": ParagraphStyle("c", parent=ss["Normal"], fontName="Courier", fontSize=7.6,
                               leading=9.6, textColor=INK),
        "cell": ParagraphStyle("cell", parent=ss["Normal"], fontSize=8.2, leading=11),
        "cellh": ParagraphStyle("ch", parent=ss["Normal"], fontSize=8.2, leading=11,
                                textColor=colors.white),
        "small": ParagraphStyle("sm", parent=ss["Normal"], fontSize=7.8, leading=10,
                                textColor=MUTED),
    }


# ReportLab's base fonts use WinAnsiEncoding. Anything outside it renders as a
# solid black box, which looks like a bug to anyone reading the brief. Map every
# such character to a safe equivalent rather than hoping it survives.
SAFE = {
    "\u20b9": "Rs ",   # rupee sign - NOT in WinAnsi, this is the one that boxes
    "\u2265": ">=", "\u2264": "<=", "\u2260": "!=", "\u00d7": "x",
    "\u2192": "->", "\u2190": "<-", "\u2194": "<->", "\u21d2": "=>",
    "\u2227": "AND", "\u2228": "OR",
    "\u2500": "-", "\u2502": "|", "\u251c": "+", "\u2514": "+",
    "\u250c": "+", "\u2510": "+", "\u2518": "+", "\u252c": "+", "\u2534": "+",
}


def safe_text(t: str) -> str:
    for k, v in SAFE.items():
        t = t.replace(k, v)
    return "".join(c if _ok(c) else "?" for c in t)


def _ok(c: str) -> bool:
    try:
        c.encode("cp1252")
        return True
    except UnicodeEncodeError:
        return False


def inline(t: str) -> str:
    t = html.escape(safe_text(t))
    t = re.sub(r"`([^`]+)`", r'<font face="Courier" size="8.2" color="#22394E">\1</font>', t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"(?<!\*)\*([^*]+)\*(?!\*)", r"<i>\1</i>", t)
    return t


def render(md: str, out_path, title, subtitle=""):
    S = styles()
    doc = SimpleDocTemplate(str(out_path), pagesize=A4,
                            leftMargin=17 * mm, rightMargin=17 * mm,
                            topMargin=14 * mm, bottomMargin=14 * mm, title=title)
    st = []
    lines = md.split("\n")
    i = 0
    bullets, numbered, tbl, code = [], [], [], []

    def flush():
        nonlocal bullets, numbered, tbl, code
        if bullets:
            st.append(ListFlowable(
                [ListItem(Paragraph(inline(b), S["li"]), leftIndent=12) for b in bullets],
                bulletType="bullet", start="\u2022", bulletFontSize=9,
                bulletFontName="Helvetica-Bold", leftIndent=13, bulletOffsetY=0.5))
            st.append(Spacer(1, 4)); bullets = []
        if numbered:
            st.append(ListFlowable(
                [ListItem(Paragraph(inline(b), S["li"]), leftIndent=12) for b in numbered],
                bulletType="1", leftIndent=15))
            st.append(Spacer(1, 4)); numbered = []
        if code:
            body = "<br/>".join(html.escape(safe_text(c)).replace(" ", "&nbsp;") for c in code)
            t = Table([[Paragraph(body, S["code"])]], colWidths=(176 * mm,))
            t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), CODEBG),
                                   ("PADDING", (0, 0), (-1, -1), 7),
                                   ("LINEBEFORE", (0, 0), (0, -1), 2, INK2)]))
            st.append(t); st.append(Spacer(1, 6)); code = []
        if tbl:
            rows = [[c.strip() for c in r.strip().strip("|").split("|")] for r in tbl]
            rows = [r for r in rows if not all(set(c) <= set("-: ") for c in r)]
            n = max(len(r) for r in rows)
            data = [[Paragraph(inline(c), S["cellh"] if k == 0 else S["cell"])
                     for c in (r + [""] * (n - len(r)))] for k, r in enumerate(rows)]
            w = 176 * mm
            first = 0.30 if n <= 3 else 0.24
            widths = [w * first] + [w * (1 - first) / (n - 1)] * (n - 1) if n > 1 else [w]
            t = Table(data, colWidths=widths, repeatRows=1)
            t.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), INK),
                ("GRID", (0, 0), (-1, -1), 0.25, RULE),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, PAPER]),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("PADDING", (0, 0), (-1, -1), 4.5),
            ]))
            st.append(t); st.append(Spacer(1, 7)); tbl = []

    in_code = False
    while i < len(lines):
        ln = lines[i]
        s = ln.rstrip()
        if s.startswith("```"):
            if in_code:
                in_code = False; flush()
            else:
                flush(); in_code = True
            i += 1; continue
        if in_code:
            code.append(ln); i += 1; continue
        if s.startswith("|"):
            tbl.append(s); i += 1; continue
        if tbl:
            flush()
        if not s.strip():
            flush(); i += 1; continue
        if s.startswith("### "):
            flush(); st.append(Paragraph(inline(s[4:]), S["h3"]))
        elif s.startswith("## "):
            flush(); st.append(Paragraph(inline(s[3:]), S["h2"]))
        elif s.startswith("# "):
            flush(); st.append(Paragraph(inline(s[2:]), S["h1"]))
        elif s.strip() == "---":
            flush(); st.append(HRFlowable(width="100%", thickness=0.6, color=RULE,
                                          spaceBefore=5, spaceAfter=7))
        elif s.strip() == "\\pagebreak":
            flush(); st.append(PageBreak())
        elif s.startswith("> "):
            flush()
            t = Table([[Paragraph(inline(s[2:]), S["quote"])]], colWidths=(176 * mm,))
            t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), PAPER),
                                   ("PADDING", (0, 0), (-1, -1), 8),
                                   ("LINEBEFORE", (0, 0), (0, -1), 2.5, RED)]))
            st.append(t); st.append(Spacer(1, 6))
        elif re.match(r"^\s*[-*] ", s):
            if numbered: flush()
            bullets.append(re.sub(r"^\s*[-*] ", "", s))
        elif re.match(r"^\s*\d+\. ", s):
            if bullets: flush()
            numbered.append(re.sub(r"^\s*\d+\. ", "", s))
        else:
            flush(); st.append(Paragraph(inline(s), S["p"]))
        i += 1
    flush()

    def deco(canvas, d):
        canvas.saveState()
        canvas.setFont("Helvetica", 7)
        canvas.setFillColor(MUTED)
        canvas.drawString(17 * mm, 8 * mm, f"MPLADS Sentinel · {subtitle or title}")
        canvas.drawRightString(A4[0] - 17 * mm, 8 * mm, f"Page {canvas.getPageNumber()}")
        canvas.setStrokeColor(RULE); canvas.setLineWidth(0.4)
        canvas.line(17 * mm, 11 * mm, A4[0] - 17 * mm, 11 * mm)
        canvas.restoreState()

    doc.build(st, onFirstPage=deco, onLaterPages=deco)
    return Path(out_path)
