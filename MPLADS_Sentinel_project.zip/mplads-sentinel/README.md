# MPLADS Sentinel

**A forensic risk-intelligence layer over MPLADS–eSAKSHI.**

MPLADS went digital on 1 April 2023 with the eSAKSHI portal (MoSPI / NIC). eSAKSHI
digitised the *transaction* — recommend, sanction, pay, upload proof. It does not do
*risk*. Sentinel is the analytics layer that sits on top of it, the way a fraud engine
sits on a bank's core banking system.

Two design commitments run through the whole system:

1. **Prevention over post-mortem.** A pre-sanction gate returns an advisory verdict
   before money is committed, rather than a report after it has moved.
2. **Every flag is actionable.** Each finding carries an evidence table, the MPLADS
   guideline clause it engages, and the CAG audit-paragraph family that covers it.
   A flag without a clause is a rumour; a flag with a clause is an inspection order.

---

## Quickstart

```bash
pip install -r requirements.txt

python -m sentinel.generate      # build corpus + ground truth  -> data/
python -m sentinel.pipeline      # run all 7 engines            -> out/
python -m sentinel.evaluate      # precision / recall / ablation
python -m sentinel.dossier       # top-3 audit dossier PDFs
python build_dashboard.py        # bake standalone console
python build_docs.py             # render team briefs to PDF

uvicorn api.main:app --port 8000     # live API + interactive docs at /docs
open dashboard/dashboard.html        # standalone console, no server needed
```

No Docker, no database, no network required.

## Results

| Engine | Catches | P | R | F1 |
|---|---|---|---|---|
| Duplicate work | Same asset billed twice under a rephrased name | 0.933 | 1.000 | 0.966 |
| Cost overrun | Inflated estimates vs Schedule of Rates | 0.933 | 1.000 | 0.966 |
| Split tender | One work broken up to dodge the threshold | 1.000 | 1.000 | 1.000 |
| Ghost asset | Reused completion photograph | 1.000 | 1.000 | 1.000 |
| Stalled work | Abandoned works, funds parked | 1.000 | 1.000 | 1.000 |
| Ineligible work | Private/religious land, no recommendation | 1.000 | 1.000 | 1.000 |
| March rush | End-of-year bunching (aggregate signal) | 0.579 | 1.000 | 0.733 |

**Whole system: precision 0.977, recall 1.000, F1 0.988.**
**Naive baseline (raw TF-IDF @ 0.82 + plain IsolationForest): F1 0.295.**
**Runtime: ~700 ms for 2,496 works.**

> **Honesty note.** The planted frauds are separable by construction, so F1 0.988 is an
> upper bound and not a field accuracy estimate. The defensible claim is the *ablation
> delta* on identical data — that gap measures the engineering, not the corpus. Field
> accuracy would be lower for any system; the disposal loop exists to retune thresholds
> on real inspection outcomes.

## Layout

```
sentinel/
  config.py        thresholds, SoR benchmarks, guideline clause + CAG hooks
  generate.py      synthetic corpus with labelled fraud          (Member 2)
  schema.py        canonical record, loader, validation          (Member 2)
  normalize.py     transliteration folding, boilerplate strip    (Member 1)
  engines/
    duplicate.py     text similarity AND spatial buffer          (Member 1)
    cost.py          SoR ratio + robust peer-group z (MAD)       (Member 5)
    structuring.py   split-tender clustering + HHI graph         (Member 2)
    integrity.py     stall, ghost asset, compliance, march rush  (Members 3 & 5)
  risk.py          aggregation, evidence packets, hash ledger    (Member 3)
  pipeline.py      orchestrator                                  (Member 3)
  evaluate.py      P/R/F1, ablation, threshold sweep             (Member 1)
  dossier.py       forensic audit dossier PDF                    (Member 3)
api/main.py        FastAPI: queue, gate, disposal, dossier       (Member 3)
dashboard/         Ministry / DM / MP / gate console             (Member 4)
docs/              team briefs (markdown + rendered PDF)
data/              projects.csv, ground_truth.csv
out/               findings, packets, KPIs, ledger, dossiers
```

## Before the finale

1. Replace the placeholder clause strings in `config.py::LEGAL_HOOKS` with exact
   clause numbers from the MPLADS Guidelines 2023 PDF on mplads.mospi.gov.in.
   A MoSPI judge will know these by heart. Highest return on time of anything here.
2. Check the eSAKSHI public dashboard and data.gov.in for a project-level export.
   `schema.py` will load real data unchanged, and demoing on even one district of
   real records beats synthetic outright.
3. Quote two real CAG audit paragraphs on MPLADS. Grounding the fraud typology in
   published audit findings rather than invented categories is a large credibility
   difference.
