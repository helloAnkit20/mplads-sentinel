# MPLADS Sentinel — Team Master Brief

**A forensic risk-intelligence layer over MPLADS–eSAKSHI.**
Everyone on the team reads this document. Your own brief goes deeper on your subsystem.

---

## 1. The positioning — memorise this, all five of you

MPLADS went digital on **1 April 2023** with the **eSAKSHI** portal, run by MoSPI and built by NIC. MPs recommend works online with OTP verification, District Authorities sanction, Implementing Agencies raise payment requests, and payment is released on upload of proof of completion. There is a mobile app. There is a public dashboard.

**Therefore:** any pitch that opens with "officials are drowning in paper files" is dead on arrival in front of a MoSPI judge. That is the single most common way this problem statement gets lost.

> **Our one-line positioning:** "eSAKSHI digitised the transaction. It does not do risk. We are the forensic intelligence layer that sits on top of it — the way a fraud engine sits on a bank's core banking system."

**Our second reframe:** we move from post-mortem detection to a **pre-sanction gate**. Detecting a ghost road after ₹40 lakh has moved is a report. Blocking it when the District Authority clicks *Sanction* is a saved rupee.

## 2. What the system does

Seven detection engines run over the works corpus. Each finding carries a confidence, an evidence table, the **MPLADS guideline clause** it engages and the **CAG audit-paragraph family** that historically covers it. Findings aggregate into an explainable risk score, which produces a ranked inspection queue and a one-click forensic audit dossier.

| Engine | Catches | Method | P | R | F1 |
|---|---|---|---|---|---|
| Duplicate work | Same asset billed twice under a rephrased name | Normalised text similarity ∧ 150 m spatial buffer ∧ same category | 0.933 | 1.000 | 0.966 |
| Cost overrun | Inflated estimates | SoR unit-rate ratio + robust peer-group z (median/MAD) | 0.933 | 1.000 | 0.966 |
| Split tender | One work broken up to dodge the threshold | Sliding-window clustering on (agency, GP, 14 days) | 1.000 | 1.000 | 1.000 |
| Ghost asset | Asset never built | Perceptual hash reuse across completion photos | 1.000 | 1.000 | 1.000 |
| Stalled work | Abandoned works, funds parked | 270 days silent ∧ 1.5× overdue | 1.000 | 1.000 | 1.000 |
| Ineligible work | Assets on private/religious land, no recommendation | Deterministic guideline checks | 1.000 | 1.000 | 1.000 |
| March rush | End-of-year bunching | Window sanction rate vs rest-of-year rate | 0.579 | 1.000 | 0.733 |

**Whole system: precision 0.977, recall 1.000, F1 0.988.**
**Naive baseline on identical data: F1 0.295.**
**Runtime: ~700 ms for 2,496 works.**

*(March rush is an aggregate district-year signal — when a district-year is flagged, every work in the window is surfaced as context, so project-level precision is not the right measure for it. Say so before anyone points at it.)*

## 3. The honesty rule — this protects you

**Never present F1 0.988 as a field accuracy number.** Our planted frauds are separable by construction, so it is an upper bound.

The defensible claim is the **ablation delta**: on the same data, with the same labels, the naive approach scores 0.295 and ours scores 0.988. **That gap measures our engineering, not our data.**

If a judge probes accuracy, get there first: *"Our synthetic frauds are cleanly separable, so treat the absolute number as an upper bound. What's meaningful is that the obvious approach scores 0.295 on the identical corpus. Field accuracy would be lower for everyone, which is why the disposal loop retunes thresholds on real inspection outcomes."*

Volunteering a limitation before it is found is the strongest credibility move available to you.

## 4. Architecture

```
      MPLADS-eSAKSHI export  /  synthetic corpus (2,496 works)
                              |
                    schema.py  (canonical record, validation)
                              |
        +---------------------+---------------------+
        |                     |                     |
   normalize.py          geo blocking          peer-group stats
   (translit fold,       (1.1 km grid,         (median + MAD by
    boilerplate strip,    ST_DWithin            category x district)
    ward extraction)      equivalent)
        |                     |                     |
        +---------------------+---------------------+
                              |
   duplicate | cost | structuring | stalled | ghost | compliance | march
                              |
                     risk.py  aggregate()
              additive saturation -> 0-100 + evidence packet
              + LEGAL_HOOKS (guideline clause + CAG para)
                              |
        +---------------------+---------------------+
        |                     |                     |
   FastAPI (api/main.py)  dossier.py           AuditLedger
   REST + pre-sanction    forensic PDF         SHA-256 hash chain
   gate + disposal        + field checklist    append-only, verifiable
        |
   dashboard (Ministry / DM / MP / Gate)
```

## 5. How to run it

```
pip install -r requirements.txt

python -m sentinel.generate       # build the corpus + ground truth
python -m sentinel.pipeline       # run all engines -> out/
python -m sentinel.evaluate       # precision/recall/F1 + ablation
python -m sentinel.dossier        # top-3 audit dossier PDFs
python build_dashboard.py         # bake the standalone dashboard

uvicorn api.main:app --port 8000  # live API + /docs
open dashboard/dashboard.html     # standalone console, no server needed
```

Everything runs on a laptop with no Docker, no database and no network.

## 6. Shared Q&A — anyone may be asked these

**"Isn't eSAKSHI already doing this?"**
> eSAKSHI is a transaction and workflow system. It records what happened. It does not cross-compare a new proposal against every work already built within 150 metres, it does not benchmark unit rates against the Schedule of Rates, and it does not detect clusters across records. Those are analytics functions and they are what we add. We consume its data; we do not duplicate its job.

**"Are you accusing MPs of corruption?"**
> No, and the system is built so that we cannot be read that way. We output an inspection *priority*, not a verdict. The caveat is the first line of every dossier and every API response. And the MP view is a defence as much as an audit — an MP with clean works now has evidence of it on record.

**"What new data do you need from government?"**
> None. We consume what eSAKSHI already holds. Two of the three fields we add — coordinates and completion photographs — are already captured by the eSAKSHI mobile app. The third, physical quantity, is in every sanction order.

**"How would this actually get deployed?"**
> Nightly batch into PostgreSQL with PostGIS on NIC cloud. Authentication via Parichay SSO using the role mapping eSAKSHI already maintains. Reconciliation against PFMS for payment-side verification. No parallel identity system, no new data collection, no new hardware.

**"What is your false positive rate?"**
> Two false positives across 2,496 works on our labelled corpus. More importantly, false positives are *designed for*: every one gets disposed by an officer with a recorded reason, and a FALSE_POSITIVE disposal returns as a labelled negative that retunes the threshold. A system with zero false positives has its threshold set too high to catch anything.

**"Where is the AI? A lot of this is rules."**
> It is a hybrid, and each part sits where it earns its keep. ML where the problem is genuinely fuzzy — matching rephrased transliterated descriptions across languages. Statistics where distributions matter — robust peer-group benchmarking. Rules where the law is already crisp — land tenure, split tenders, recommendation sequence. Our most accurate detector is a `GROUP BY`, and that is a design win, not a shortfall: a rule an officer can restate in one sentence gets acted on; a model score gets ignored.

**"What happens at national scale?"**
> Roughly 1.5–2 lakh works a year. Only the duplicate engine is quadratic, and geo-blocking makes it near-linear. The graph is sparse. Nightly batch, materialised risk tables, API reads pre-computed results — so UI latency is independent of corpus size.

**"What's the next thing you'd build?"**
> Satellite corroboration. Bhuvan or Sentinel-2 built-up change detection at the sanctioned coordinates between sanction date and claimed completion. No change on the ground, no asset. ISRO's Bhuvan already does this for MGNREGA geotagging, so the integration path is proven.

## 7. Before the finale — a 90-minute checklist

1. **Replace the placeholder guideline clauses.** Open the MPLADS Guidelines 2023 PDF on mplads.mospi.gov.in and put exact clause numbers into `config.py::LEGAL_HOOKS`. A MoSPI judge will know these by heart. Highest return on time of anything on this list.
2. **Check the eSAKSHI public dashboard and data.gov.in** for any project-level MPLADS export. Demoing on even one district of real data beats synthetic outright — and `schema.py` will load it unchanged.
3. **Pull two real CAG audit paragraphs** on MPLADS and quote them on a slide. Grounding the fraud typology in published audit findings rather than invented categories is a large credibility difference.
4. **Rehearse Scenario A until it is muscle memory.** Whoever demos should be able to do it while talking, without looking at the screen.
5. **Test the offline path.** Turn wifi off, double-click `dashboard/dashboard.html`, confirm the SVG fallback map renders.
6. **Agree who answers what.** When a judge asks a question, one person answers. Two people answering the same question looks like a team that has not rehearsed.

## 8. What to do if something breaks on stage

- **API won't start** → open `dashboard/dashboard.html` directly. Say: "We ship a self-contained build precisely for this." Keep moving. Do not debug in front of judges.
- **Map is blank** → the CDN is unreachable; the SVG fallback should render. Say so plainly and continue.
- **A judge finds a bug** → "Good catch, that's a real limitation." Write it down visibly. Never argue. Never bluff a number you do not have.
- **You do not know an answer** → "I don't know, and I'd rather not guess. Here's how we'd find out." That answer scores better than a confident wrong one, every time.
