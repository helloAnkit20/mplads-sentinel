"""
Renders the team briefs from docs/*.md into PDFs.

    python build_docs.py
"""
from pathlib import Path

from docgen import render

ROOT = Path(__file__).resolve().parent
DOCS = ROOT / "docs"

BRIEFS = [
    ("master.md", "MPLADS_Sentinel_TEAM_MASTER_BRIEF.pdf",
     "MPLADS Sentinel - Team Master Brief", "Team master brief"),
    ("m1.md", "MEMBER_1_Detection_Science.pdf",
     "Member 1 - Detection Science", "Member 1 - duplicate engine & evaluation"),
    ("m2.md", "MEMBER_2_Data_Spatial_Graph.pdf",
     "Member 2 - Data, Spatial & Collusion Graph", "Member 2 - data, spatial, split-tender graph"),
    ("m3.md", "MEMBER_3_Backend_Risk_Dossier.pdf",
     "Member 3 - Backend, Risk & Dossier", "Member 3 - backend, risk aggregation, audit dossier"),
    ("m4.md", "MEMBER_4_Frontend_Role_Views.pdf",
     "Member 4 - Frontend & Role Views", "Member 4 - dashboard, role views, visualisation"),
    ("m5.md", "MEMBER_5_Cost_Ghost_Pitch.pdf",
     "Member 5 - Cost Forensics, Ghost Assets & Pitch", "Member 5 - cost forensics, ghost assets, pitch"),
]


def main():
    for src, out, title, subtitle in BRIEFS:
        md = (DOCS / src).read_text(encoding="utf-8")
        p = render(md, DOCS / out, title, subtitle)
        print(f"wrote {p.name}  ({p.stat().st_size/1024:.0f} KB)")


if __name__ == "__main__":
    main()
